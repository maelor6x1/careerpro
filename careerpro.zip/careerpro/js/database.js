/**
 * database.js
 * ---------------------------------------------------------------------------
 * Central data layer for CareerPro. Clubs, leagues and formats below reflect
 * the real 2026 season as researched (Brasileirão Série A 2026, Premier
 * League/LaLiga/Serie A/Bundesliga/Ligue 1/Primeira Liga/Eredivisie 2026-27,
 * Liga Profesional Argentina 2026). Since rosters change every window, this
 * is a snapshot, not a live feed — if it goes stale, only the club lists
 * below need updating, nothing else in the engine depends on specific names.
 *
 * Player rosters for CPU clubs are still procedurally generated (see
 * player.js) rather than hand-typed real squads — full accurate rosters for
 * ~230 clubs across 9 leagues, kept current, isn't something this project
 * can reliably guarantee, so it focuses real-world accuracy on the clubs,
 * leagues and formats instead.
 * ---------------------------------------------------------------------------
 */

const DB = (() => {

  // ---------------------------------------------------------------------
  // CREST HELPER — tries a real crest from an open badge repository, falls
  // back to a generated SVG monogram badge if the image 404s (renamed club,
  // repo path mismatch, offline, etc). The fallback always renders, so a
  // broken image is never shown to the person.
  // ---------------------------------------------------------------------
  function crestUrl(club) {
    const league = CREST_LEAGUE_FOLDER[club.league] || club.league;
    return `https://raw.githubusercontent.com/luukhopman/football-logos/master/logos/${encodeURIComponent(league)}/${encodeURIComponent(club.name)}.png`;
  }

  // All club crests now come from Wikipedia's public summary API (which
  // returns each article's infobox image), fetched once at boot and
  // cached — see WIKI_TITLE below and prefetchClubCrests(). The
  // football-logos repo folder map is kept only as a last-resort fallback
  // for any club id that isn't in WIKI_TITLE, since its exact per-team file
  // naming couldn't be reliably verified.
  const CREST_LEAGUE_FOLDER = {
    ENG: 'England - Premier League', ESP: 'Spain - LaLiga', ITA: 'Italy - Serie A',
    GER: 'Germany - Bundesliga', FRA: 'France - Ligue 1', POR: 'Portugal - Primeira Liga',
    NED: 'Netherlands - Eredivisie',
  };

  const WIKI_TITLE = {
    'athletico-paranaense': 'Club Athletico Paranaense', 'atletico-mineiro': 'Clube Atlético Mineiro',
    bahia: 'Esporte Clube Bahia', botafogo: 'Botafogo de Futebol e Regatas', chapecoense: 'Associação Chapecoense de Futebol',
    corinthians: 'Sport Club Corinthians Paulista', coritiba: 'Coritiba Foot Ball Club', cruzeiro: 'Cruzeiro EC',
    flamengo: 'Clube de Regatas do Flamengo', fluminense: 'Fluminense Football Club', gremio: 'Grêmio Foot-Ball Porto Alegrense',
    internacional: 'Sport Club Internacional', mirassol: 'Mirassol Futebol Clube', palmeiras: 'Sociedade Esportiva Palmeiras',
    'red-bull-bragantino': 'Red Bull Bragantino', remo: 'Clube do Remo', santos: 'Santos Futebol Clube',
    'sao-paulo': 'São Paulo Futebol Clube', 'vasco-da-gama': 'Club de Regatas Vasco da Gama', vitoria: 'Esporte Clube Vitória',
    'river-plate': 'Club Atlético River Plate', 'racing-club': 'Racing Club', 'san-lorenzo': 'Club Atlético San Lorenzo de Almagro',
    'velez-sarsfield': 'Club Atlético Vélez Sarsfield', talleres: 'Club Atlético Talleres', 'lanus': 'Club Atlético Lanús',
    banfield: 'Club Atlético Banfield', tigre: 'Club Atlético Tigre', instituto: 'Instituto Atlético Central Córdoba',
    sarmiento: 'Club Atlético Sarmiento', 'central-cordoba': 'Central Córdoba de Santiago del Estero',
    union: 'Club Atlético Unión', belgrano: 'Club Atlético Belgrano', 'atletico-tucuman': 'Club Atlético Tucumán',
    'gimnasia-de-mendoza': 'Gimnasia y Esgrima de Mendoza', 'boca-juniors': 'Club Atlético Boca Juniors',
    independiente: 'Club Atlético Independiente', 'estudiantes-de-la-plata': 'Club Estudiantes de La Plata',
    'newells-old-boys': "Club Atlético Newell's Old Boys", 'rosario-central': 'Rosario Central',
    'argentinos-juniors': 'Asociación Atlética Argentinos Juniors', huracan: 'Club Atlético Huracán',
    platense: 'Club Atlético Platense', 'barracas-central': 'Club Atlético Barracas Central',
    'defensa-y-justicia': 'Club Social y Deportivo Defensa y Justicia', 'independiente-rivadavia': 'Club Atlético Independiente Rivadavia',
    'deportivo-riestra': 'Club Deportivo Social y Cultural Riestra', 'gimnasia-la-plata': 'Club de Gimnasia y Esgrima La Plata',
    colon: 'Club Atlético Colón', 'estudiantes-de-rio-cuarto': 'Estudiantes de Río Cuarto',

    // England
    arsenal: 'Arsenal F.C.', 'manchester-city': 'Manchester City F.C.', 'manchester-united': 'Manchester United F.C.',
    'aston-villa': 'Aston Villa F.C.', liverpool: 'Liverpool F.C.', bournemouth: 'A.F.C. Bournemouth',
    sunderland: 'Sunderland A.F.C.', 'brighton-hove-albion': 'Brighton & Hove Albion F.C.', chelsea: 'Chelsea F.C.',
    'tottenham-hotspur': 'Tottenham Hotspur F.C.', 'newcastle-united': 'Newcastle United F.C.', everton: 'Everton F.C.',
    fulham: 'Fulham F.C.', brentford: 'Brentford F.C.', 'crystal-palace': 'Crystal Palace F.C.',
    'nottingham-forest': 'Nottingham Forest F.C.', 'leeds-united': 'Leeds United F.C.', 'coventry-city': 'Coventry City F.C.',
    'ipswich-town': 'Ipswich Town F.C.', 'hull-city': 'Hull City A.F.C.',

    // Spain
    'real-madrid': 'Real Madrid Club de Fútbol', barcelona: 'Futbol Club Barcelona', villarreal: 'Villarreal Club de Fútbol',
    'atletico-de-madrid': 'Club Atlético de Madrid', 'real-betis': 'Real Betis Balompié', 'celta-de-vigo': 'Real Club Celta de Vigo',
    'real-sociedad': 'Real Sociedad de Fútbol', 'athletic-club': 'Athletic Club', sevilla: 'Sevilla Fútbol Club',
    valencia: 'Valencia Club de Fútbol', getafe: 'Getafe Club de Fútbol', osasuna: 'Club Atlético Osasuna',
    espanyol: 'Reial Club Deportiu Espanyol', 'rayo-vallecano': 'Rayo Vallecano de Madrid', alaves: 'Deportivo Alavés',
    elche: 'Elche Club de Fútbol', levante: 'Levante Unión Deportiva', 'racing-de-santander': 'Real Racing Club de Santander',
    'deportivo-de-la-coruna': 'Real Club Deportivo de La Coruña', malaga: 'Málaga Club de Fútbol',

    // Italy
    'inter-de-milao': 'Football Club Internazionale Milano', napoli: 'Società Sportiva Calcio Napoli',
    juventus: 'Juventus Football Club', 'ac-milan': 'Associazione Calcio Milan', 'as-roma': 'Associazione Sportiva Roma',
    atalanta: 'Atalanta Bergamasca Calcio', bologna: 'Bologna Football Club 1909', lazio: 'Società Sportiva Lazio',
    fiorentina: 'Associazione Calcio Firenze Fiorentina', udinese: 'Udinese Calcio', torino: 'Torino Football Club',
    genoa: 'Genoa Cricket and Football Club', como: 'Como 1907', cagliari: 'Cagliari Calcio', lecce: 'Unione Sportiva Lecce',
    parma: 'Parma Calcio 1913', sassuolo: 'Unione Sportiva Sassuolo Calcio', venezia: 'Venezia Football Club',
    frosinone: 'Frosinone Calcio', monza: 'Associazione Calcio Monza',

    // Germany
    'bayern-de-munique': 'FC Bayern München', 'borussia-dortmund': 'Borussia Dortmund',
    'bayer-leverkusen': 'Bayer 04 Leverkusen', 'rb-leipzig': 'RB Leipzig', 'eintracht-frankfurt': 'Eintracht Frankfurt',
    'vfb-stuttgart': 'VfB Stuttgart', 'borussia-monchengladbach': 'Borussia Mönchengladbach', '1-fc-koln': '1. FC Köln',
    'werder-bremen': 'SV Werder Bremen', 'mainz-05': '1. FSV Mainz 05', 'union-berlin': '1. FC Union Berlin',
    'sc-freiburg': 'SC Freiburg', 'fc-augsburg': 'FC Augsburg', 'tsg-hoffenheim': 'TSG 1899 Hoffenheim',
    'hamburger-sv': 'Hamburger SV', 'fc-schalke-04': 'FC Schalke 04', 'sv-elversberg': 'SV Elversberg',
    'sc-paderborn-07': 'SC Paderborn 07',

    // France
    'paris-saint-germain': 'Paris Saint-Germain Football Club', 'as-monaco': 'Association Sportive de Monaco Football Club',
    'olympique-de-marselha': 'Olympique de Marselha', 'losc-lille': 'Lille Olympique Sporting Club',
    'rc-lens': 'Racing Club de Lens', 'olympique-lyonnais': 'Olympique Lyonnais', 'ogc-nice': 'OGC Nice',
    'rc-strasbourg': 'Racing Club de Strasbourg Alsace', 'stade-rennais-fc': 'Stade Rennais Football Club',
    'stade-brestois-29': 'Stade Brestois 29', 'aj-auxerre': 'Association de la Jeunesse Auxerroise',
    'toulouse-fc': 'Toulouse Football Club', 'angers-sco': "Angers Sporting Club de l'Ouest",
    'le-havre-ac': 'Le Havre Athletic Club', 'fc-lorient': 'Football Club Lorient', 'paris-fc': 'Paris FC',
    'le-mans-fc': 'Le Mans Football Club', 'estac-troyes': 'Espérance Sportive Troyes Aube Champagne',

    // Portugal
    'fc-porto': 'Futebol Clube do Porto', benfica: 'Sport Lisboa e Benfica', 'sporting-cp': 'Sporting Clube de Portugal',
    'sc-braga': 'Sporting Clube de Braga', 'vitoria-de-guimaraes': 'Vitória Sport Clube', famalicao: 'Futebol Clube de Famalicão',
    moreirense: 'Moreirense Futebol Clube', 'gil-vicente': 'Gil Vicente Futebol Clube', arouca: 'Futebol Clube de Arouca',
    'casa-pia': 'Casa Pia Atlético Clube', 'estoril-praia': 'Grupo Desportivo Estoril Praia',
    'estrela-da-amadora': 'Clube de Futebol Estrela da Amadora', 'rio-ave': 'Rio Ave Futebol Clube',
    'santa-clara': 'Clube Desportivo Santa Clara', nacional: 'Clube Desportivo Nacional', alverca: 'Futebol Clube de Alverca',
    maritimo: 'Clube Desportivo Marítimo', 'academico-de-viseu': 'Académico de Viseu Futebol Clube',

    // Netherlands
    ajax: 'AFC Ajax', 'psv-eindhoven': 'PSV Eindhoven', feyenoord: 'Feyenoord Rotterdam', 'az-alkmaar': 'AZ Alkmaar',
    'fc-twente': 'FC Twente', 'fc-utrecht': 'FC Utrecht', 'go-ahead-eagles': 'Go Ahead Eagles', 'fc-groningen': 'FC Groningen',
    'sc-heerenveen': 'sc Heerenveen', 'sparta-rotterdam': 'Sparta Rotterdam', 'fortuna-sittard': 'Fortuna Sittard',
    'nec-nijmegen': 'NEC Nijmegen', 'pec-zwolle': 'PEC Zwolle', excelsior: 'SBV Excelsior', telstar: 'SC Telstar',
    'ado-den-haag': 'ADO Den Haag', 'sc-cambuur': 'SC Cambuur', 'willem-ii': 'Willem II (voetbalclub)',

    // Extra CONMEBOL countries
    penarol: 'Club Atlético Peñarol', 'nacional-de-montevideo': 'Club Nacional de Football', danubio: 'Danubio Fútbol Club',
    'defensor-sporting': 'Defensor Sporting Club', millonarios: 'Millonarios Fútbol Club',
    'atletico-nacional': 'Atlético Nacional', 'america-de-cali': 'América de Cali',
    'junior-de-barranquilla': 'Junior Fútbol Club', 'colo-colo': 'Club Social y Deportivo Colo-Colo',
    'universidad-de-chile': 'Club Universidad de Chile', 'universidad-catolica': 'Club Deportivo Universidad Católica',
    palestino: 'Club Deportivo Palestino', olimpia: 'Club Olimpia', 'cerro-porteno': 'Club Cerro Porteño',
    libertad: 'Club Libertad', 'barcelona-sc': 'Barcelona Sporting Club', 'ldu-quito': 'Liga Deportiva Universitaria de Quito',
    emelec: 'Club Sport Emelec', 'independiente-del-valle': 'Independiente del Valle',
    universitario: 'Club Universitario de Deportes', 'alianza-lima': 'Club Alianza Lima', 'sporting-cristal': 'Club Sporting Cristal',

    // Extra UEFA countries
    'club-brugge': 'Club Brugge KV', anderlecht: 'Royal Sporting Club Anderlecht',
    'union-saint-gilloise': 'Royale Union Saint-Gilloise', genk: 'Koninklijke Racing Club Genk',
    celtic: 'Celtic F.C.', rangers: 'Rangers F.C.', galatasaray: 'Galatasaray S.K.', fenerbahce: 'Fenerbahçe S.K.',
    besiktas: 'Beşiktaş J.K.', olympiacos: 'Olympiacos F.C.', panathinaikos: 'Panathinaikos F.C.',
    'aek-athens': 'AEK Athens F.C.', 'young-boys': 'BSC Young Boys', 'fc-basel': 'FC Basel',
    'red-bull-salzburg': 'FC Red Bull Salzburg', 'rapid-wien': 'SK Rapid Wien', 'dinamo-zagreb': 'GNK Dinamo Zagreb',
    'hajduk-split': 'HNK Hajduk Split', 'shakhtar-donetsk': 'FC Shakhtar Donetsk', 'dynamo-kyiv': 'FC Dynamo Kyiv',
    'fc-copenhagen': 'FC Copenhagen', 'brondby': 'Brøndby IF', 'sparta-prague': 'AC Sparta Praha',
    'slavia-prague': 'SK Slavia Praha',
  };

  function crestUrl(club) {
    if (WIKI_TITLE[club.id]) return null; // resolved asynchronously via crestCache instead
    const league = CREST_LEAGUE_FOLDER[club.league] || club.league;
    return `https://raw.githubusercontent.com/luukhopman/football-logos/master/logos/${encodeURIComponent(league)}/${encodeURIComponent(club.name)}.png`;
  }

  const crestCache = {}; // clubId -> resolved image URL, filled in by prefetchClubCrests()
  let prefetchStarted = false;
  function prefetchClubCrests(onComplete) {
    if (prefetchStarted || typeof fetch === 'undefined') return;
    prefetchStarted = true;
    const jobs = Object.entries(WIKI_TITLE).map(([clubId, title]) =>
      fetch(`https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`)
        .then(r => r.ok ? r.json() : null)
        .then(data => { const url = data && data.thumbnail && data.thumbnail.source; if (url) crestCache[clubId] = url; })
        .catch(() => {}));
    Promise.allSettled(jobs).then(() => { if (onComplete) onComplete(); });
  }

  // National-team "crests" use real country flags from a stable public CDN
  // (flagcdn.com) — far more reliable than guessing per-team badge files,
  // since it only needs a standard ISO country code.
  const NATION_ISO = {
    Brasil: 'br', Argentina: 'ar', Uruguai: 'uy', Colômbia: 'co', Chile: 'cl', Paraguai: 'py',
    Peru: 'pe', Equador: 'ec', Bolívia: 'bo', Venezuela: 've',
    Inglaterra: 'gb-eng', Espanha: 'es', Itália: 'it', Alemanha: 'de', França: 'fr',
    Portugal: 'pt', Holanda: 'nl', Bélgica: 'be', Croácia: 'hr',
    'Estados Unidos': 'us', México: 'mx', Canadá: 'ca',
    Nigéria: 'ng', Senegal: 'sn', Marrocos: 'ma', Japão: 'jp', 'Coreia do Sul': 'kr',
  };
  function flagUrl(nationality) {
    const iso = NATION_ISO[nationality];
    return iso ? `https://flagcdn.com/w160/${iso}.png` : null;
  }

  function monogramSVG(name, color1, color2) {
    const initials = name.split(' ').filter(w => w.length > 2 || w === w.toUpperCase())
      .slice(0, 2).map(w => w[0]).join('').toUpperCase() || name.slice(0, 2).toUpperCase();
    return `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
        <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="${color1}"/><stop offset="1" stop-color="${color2}"/>
        </linearGradient></defs>
        <polygon points="50,4 92,26 92,70 50,96 8,70 8,26" fill="url(#g)" stroke="#0a0a0a" stroke-width="3"/>
        <text x="50" y="62" font-family="Arial Black, sans-serif" font-size="34" fill="#fff"
          text-anchor="middle" font-weight="900">${initials}</text>
      </svg>`)}`;
  }

  // ---------------------------------------------------------------------
  // LEAGUES — real formats. `format`: 'double' = home+away round robin,
  // 'zones' = Argentina's split-zone + playoff format.
  // ---------------------------------------------------------------------
  const LEAGUES = {
    BRA: { name: 'Brasileirão Série A', country: 'Brasil', tier: 1, flag: '🇧🇷', format: 'double' },
    ARG: { name: 'Liga Profesional', country: 'Argentina', tier: 1, flag: '🇦🇷', format: 'zones' },
    ENG: { name: 'Premier League', country: 'Inglaterra', tier: 1, flag: '🏴', format: 'double' },
    ESP: { name: 'LaLiga', country: 'Espanha', tier: 1, flag: '🇪🇸', format: 'double' },
    ITA: { name: 'Serie A', country: 'Itália', tier: 1, flag: '🇮🇹', format: 'double' },
    GER: { name: 'Bundesliga', country: 'Alemanha', tier: 1, flag: '🇩🇪', format: 'double' },
    FRA: { name: 'Ligue 1', country: 'França', tier: 1, flag: '🇫🇷', format: 'double' },
    POR: { name: 'Primeira Liga', country: 'Portugal', tier: 1, flag: '🇵🇹', format: 'double' },
    NED: { name: 'Eredivisie', country: 'Holanda', tier: 1, flag: '🇳🇱', format: 'double' },
  };

  // Brazilian state championships (played before the Brasileirão)
  const ESTADUAIS = {
    MG: 'Campeonato Mineiro', RJ: 'Campeonato Carioca', SP: 'Campeonato Paulista',
    RS: 'Campeonato Gaúcho', BA: 'Campeonato Baiano', PE: 'Campeonato Pernambucano',
    CE: 'Campeonato Cearense', PR: 'Campeonato Paranaense', SC: 'Campeonato Catarinense', PA: 'Campeonato Paraense',
  };

  // Real cup competitions per league (knockout, seeded from the league's own clubs)
  const CUPS = {
    BRA: 'Copa do Brasil', ARG: 'Copa Argentina', ENG: 'FA Cup', ESP: 'Copa del Rey',
    ITA: 'Coppa Italia', GER: 'DFB-Pokal', FRA: 'Coupe de France', POR: 'Taça de Portugal', NED: 'KNVB Beker',
  };

  function club(name, league, opts) {
    opts = opts || {};
    const c = {
      id: slug(name), name, league, state: opts.state || null, zone: opts.zone || null,
      stadium: opts.stadium || `Estádio ${name}`, reputation: opts.rep || 65,
      colors: opts.colors || ['#1c1c1c', '#3a3a3a'],
      budget: Math.round((opts.rep || 65) * (opts.rep || 65) * 1200 * (0.8 + Math.random() * 0.6)),
    };
    Object.defineProperty(c, 'coach', {
      enumerable: true, configurable: true,
      get() { const n = randomCoachName(league); Object.defineProperty(c, 'coach', { value: n, enumerable: true }); return n; },
    });
    return c;
  }

  function slug(s) { return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-'); }

  // ---------------------------------------------------------------------
  // CLUBS — real 2026-season top-flight participants for each league.
  // ---------------------------------------------------------------------
  const CLUBS = [
    // ===================== BRASIL — Brasileirão Série A 2026 (20 clubes) =====================
    club('Athletico Paranaense', 'BRA', { state: 'PR', stadium: 'Arena da Baixada', rep: 74, colors: ['#c8102e', '#000000'] }),
    club('Atlético Mineiro', 'BRA', { state: 'MG', stadium: 'Arena MRV', rep: 79, colors: ['#000000', '#3d0a0a'] }),
    club('Bahia', 'BRA', { state: 'BA', stadium: 'Arena Fonte Nova', rep: 75, colors: ['#1c3f94', '#c8102e'] }),
    club('Botafogo', 'BRA', { state: 'RJ', stadium: 'Nilton Santos', rep: 80, colors: ['#000000', '#ffffff'] }),
    club('Chapecoense', 'BRA', { state: 'SC', stadium: 'Arena Condá', rep: 65, colors: ['#046a38', '#ffffff'] }),
    club('Corinthians', 'BRA', { state: 'SP', stadium: 'Neo Química Arena', rep: 78, colors: ['#000000', '#ffffff'] }),
    club('Coritiba', 'BRA', { state: 'PR', stadium: 'Couto Pereira', rep: 68, colors: ['#00873e', '#000000'] }),
    club('Cruzeiro', 'BRA', { state: 'MG', stadium: 'Mineirão', rep: 78, colors: ['#003399', '#001a4d'] }),
    club('Flamengo', 'BRA', { state: 'RJ', stadium: 'Maracanã', rep: 86, colors: ['#c8102e', '#000000'] }),
    club('Fluminense', 'BRA', { state: 'RJ', stadium: 'Maracanã', rep: 78, colors: ['#7a1e3c', '#046a38'] }),
    club('Grêmio', 'BRA', { state: 'RS', stadium: 'Arena do Grêmio', rep: 78, colors: ['#046a38', '#003399'] }),
    club('Internacional', 'BRA', { state: 'RS', stadium: 'Beira-Rio', rep: 78, colors: ['#c8102e', '#ffffff'] }),
    club('Mirassol', 'BRA', { state: 'SP', stadium: 'Campos Maia', rep: 70, colors: ['#fdd000', '#046a38'] }),
    club('Palmeiras', 'BRA', { state: 'SP', stadium: 'Allianz Parque', rep: 86, colors: ['#046a38', '#ffffff'] }),
    club('Red Bull Bragantino', 'BRA', { state: 'SP', stadium: 'Cícero de Souza Marques', rep: 74, colors: ['#ffffff', '#c8102e'] }),
    club('Remo', 'BRA', { state: 'PA', stadium: 'Baenão', rep: 64, colors: ['#003399', '#c8102e'] }),
    club('Santos', 'BRA', { state: 'SP', stadium: 'Vila Belmiro', rep: 74, colors: ['#000000', '#ffffff'] }),
    club('São Paulo', 'BRA', { state: 'SP', stadium: 'MorumBIS', rep: 79, colors: ['#c8102e', '#000000'] }),
    club('Vasco da Gama', 'BRA', { state: 'RJ', stadium: 'São Januário', rep: 73, colors: ['#000000', '#ffffff'] }),
    club('Vitória', 'BRA', { state: 'BA', stadium: 'Barradão', rep: 68, colors: ['#c8102e', '#000000'] }),

    // ===================== ARGENTINA — Liga Profesional 2026 (30 clubes, 2 zonas) =====================
    club('River Plate', 'ARG', { zone: 'A', stadium: 'Estadio Monumental', rep: 85, colors: ['#e30513', '#ffffff'] }),
    club('Racing Club', 'ARG', { zone: 'A', stadium: 'Cilindro de Avellaneda', rep: 78, colors: ['#75aadb', '#ffffff'] }),
    club('San Lorenzo', 'ARG', { zone: 'A', stadium: 'Pedro Bidegain', rep: 73, colors: ['#003399', '#c8102e'] }),
    club('Vélez Sarsfield', 'ARG', { zone: 'A', stadium: 'José Amalfitani', rep: 75, colors: ['#003399', '#ffffff'] }),
    club('Talleres', 'ARG', { zone: 'A', stadium: 'Mario Alberto Kempes', rep: 74, colors: ['#003399', '#ffffff'] }),
    club('Lanús', 'ARG', { zone: 'A', stadium: 'Ciudad de Lanús', rep: 71, colors: ['#a3021a', '#8a1538'] }),
    club('Banfield', 'ARG', { zone: 'A', stadium: 'Florencio Sola', rep: 66, colors: ['#046a38', '#ffffff'] }),
    club('Tigre', 'ARG', { zone: 'A', stadium: 'José Dellagiovanna', rep: 65, colors: ['#003399', '#ffffff'] }),
    club('Instituto', 'ARG', { zone: 'A', stadium: 'Juan Domingo Perón', rep: 63, colors: ['#c8102e', '#ffffff'] }),
    club('Sarmiento', 'ARG', { zone: 'A', stadium: 'Eva Perón', rep: 61, colors: ['#046a38', '#ffffff'] }),
    club('Central Córdoba', 'ARG', { zone: 'A', stadium: 'Alfredo Terrera', rep: 62, colors: ['#000000', '#ffffff'] }),
    club('Unión', 'ARG', { zone: 'A', stadium: '15 de Abril', rep: 64, colors: ['#c8102e', '#ffffff'] }),
    club('Belgrano', 'ARG', { zone: 'A', stadium: 'Julio César Villagra', rep: 65, colors: ['#75aadb', '#ffffff'] }),
    club('Atlético Tucumán', 'ARG', { zone: 'A', stadium: 'Monumental José Fierro', rep: 63, colors: ['#75aadb', '#ffffff'] }),
    club('Gimnasia de Mendoza', 'ARG', { zone: 'A', stadium: 'Víctor Antonio Legrotaglie', rep: 56, colors: ['#ffffff', '#003399'] }),

    club('Boca Juniors', 'ARG', { zone: 'B', stadium: 'La Bombonera', rep: 84, colors: ['#003399', '#f9d616'] }),
    club('Independiente', 'ARG', { zone: 'B', stadium: 'Libertadores de América', rep: 74, colors: ['#c8102e', '#ffffff'] }),
    club('Estudiantes de La Plata', 'ARG', { zone: 'B', stadium: 'Jorge Luis Hirschi', rep: 75, colors: ['#c8102e', '#ffffff'] }),
    club('Newell\'s Old Boys', 'ARG', { zone: 'B', stadium: 'Marcelo Bielsa', rep: 70, colors: ['#c8102e', '#000000'] }),
    club('Rosario Central', 'ARG', { zone: 'B', stadium: 'Gigante de Arroyito', rep: 71, colors: ['#f4d03f', '#003399'] }),
    club('Argentinos Juniors', 'ARG', { zone: 'B', stadium: 'Diego Armando Maradona', rep: 68, colors: ['#c8102e', '#ffffff'] }),
    club('Huracán', 'ARG', { zone: 'B', stadium: 'Tomás Adolfo Ducó', rep: 66, colors: ['#ffffff', '#c8102e'] }),
    club('Platense', 'ARG', { zone: 'B', stadium: 'Ciudad de Vicente López', rep: 67, colors: ['#003399', '#c8102e'] }),
    club('Barracas Central', 'ARG', { zone: 'B', stadium: 'Claudio Chiqui Tapia', rep: 60, colors: ['#c8102e', '#000000'] }),
    club('Defensa y Justicia', 'ARG', { zone: 'B', stadium: 'Norberto Tomaghello', rep: 65, colors: ['#046a38', '#c8102e'] }),
    club('Independiente Rivadavia', 'ARG', { zone: 'B', stadium: 'Bautista Gargantini', rep: 62, colors: ['#c8102e', '#ffffff'] }),
    club('Deportivo Riestra', 'ARG', { zone: 'B', stadium: 'Guillermo Laza', rep: 58, colors: ['#000000', '#ffffff'] }),
    club('Gimnasia La Plata', 'ARG', { zone: 'B', stadium: 'Juan Carmelo Zerillo', rep: 62, colors: ['#003399', '#ffffff'] }),
    club('Colón', 'ARG', { zone: 'B', stadium: 'Brigadier General Estanislao López', rep: 63, colors: ['#c8102e', '#000000'] }),
    club('Estudiantes de Río Cuarto', 'ARG', { zone: 'B', stadium: 'Country Club de Río Cuarto', rep: 55, colors: ['#c8102e', '#ffffff'] }),

    // ===================== INGLATERRA — Premier League 2026-27 (20 clubes) =====================
    club('Arsenal', 'ENG', { stadium: 'Emirates Stadium', rep: 89, colors: ['#ef0107', '#063672'] }),
    club('Manchester City', 'ENG', { stadium: 'Etihad Stadium', rep: 88, colors: ['#6caddf', '#1c2c5b'] }),
    club('Manchester United', 'ENG', { stadium: 'Old Trafford', rep: 83, colors: ['#da291c', '#fbe122'] }),
    club('Aston Villa', 'ENG', { stadium: 'Villa Park', rep: 80, colors: ['#670e36', '#95bfe5'] }),
    club('Liverpool', 'ENG', { stadium: 'Anfield', rep: 85, colors: ['#c8102e', '#00b2a9'] }),
    club('Bournemouth', 'ENG', { stadium: 'Vitality Stadium', rep: 74, colors: ['#da291c', '#000000'] }),
    club('Sunderland', 'ENG', { stadium: 'Stadium of Light', rep: 71, colors: ['#eb172b', '#ffffff'] }),
    club('Brighton & Hove Albion', 'ENG', { stadium: 'Amex Stadium', rep: 76, colors: ['#0057b8', '#ffcd00'] }),
    club('Chelsea', 'ENG', { stadium: 'Stamford Bridge', rep: 82, colors: ['#034694', '#ffffff'] }),
    club('Tottenham Hotspur', 'ENG', { stadium: 'Tottenham Hotspur Stadium', rep: 80, colors: ['#132257', '#ffffff'] }),
    club('Newcastle United', 'ENG', { stadium: "St James' Park", rep: 79, colors: ['#241f20', '#ffffff'] }),
    club('Everton', 'ENG', { stadium: 'Hill Dickinson Stadium', rep: 73, colors: ['#003399', '#ffffff'] }),
    club('Fulham', 'ENG', { stadium: 'Craven Cottage', rep: 72, colors: ['#000000', '#ffffff'] }),
    club('Brentford', 'ENG', { stadium: 'Gtech Community Stadium', rep: 72, colors: ['#e30613', '#ffffff'] }),
    club('Crystal Palace', 'ENG', { stadium: 'Selhurst Park', rep: 73, colors: ['#1b458f', '#c4122e'] }),
    club('Nottingham Forest', 'ENG', { stadium: 'The City Ground', rep: 74, colors: ['#dd0000', '#ffffff'] }),
    club('Leeds United', 'ENG', { stadium: 'Elland Road', rep: 72, colors: ['#ffffff', '#1d428a'] }),
    club('Coventry City', 'ENG', { stadium: 'Coventry Building Society Arena', rep: 65, colors: ['#78d0f7', '#ffffff'] }),
    club('Ipswich Town', 'ENG', { stadium: 'Portman Road', rep: 64, colors: ['#0044a9', '#ffffff'] }),
    club('Hull City', 'ENG', { stadium: 'MKM Stadium', rep: 63, colors: ['#f18a00', '#000000'] }),

    // ===================== ESPANHA — LaLiga 2026-27 (20 clubes) =====================
    club('Real Madrid', 'ESP', { stadium: 'Santiago Bernabéu', rep: 91, colors: ['#ffffff', '#febe10'] }),
    club('Barcelona', 'ESP', { stadium: 'Spotify Camp Nou', rep: 89, colors: ['#a50044', '#004d98'] }),
    club('Villarreal', 'ESP', { stadium: 'Estadio de la Cerámica', rep: 79, colors: ['#ffe667', '#005187'] }),
    club('Atlético de Madrid', 'ESP', { stadium: 'Cívitas Metropolitano', rep: 84, colors: ['#c8102e', '#0b1642'] }),
    club('Real Betis', 'ESP', { stadium: 'Benito Villamarín', rep: 78, colors: ['#00954c', '#ffffff'] }),
    club('Celta de Vigo', 'ESP', { stadium: 'Balaídos', rep: 75, colors: ['#8ac6ee', '#ffffff'] }),
    club('Real Sociedad', 'ESP', { stadium: 'Reale Arena', rep: 78, colors: ['#0067b1', '#ffffff'] }),
    club('Athletic Club', 'ESP', { stadium: 'San Mamés', rep: 79, colors: ['#ee2523', '#ffffff'] }),
    club('Sevilla', 'ESP', { stadium: 'Ramón Sánchez-Pizjuán', rep: 75, colors: ['#ffffff', '#d2001c'] }),
    club('Valencia', 'ESP', { stadium: 'Mestalla', rep: 74, colors: ['#ffffff', '#ee7c0e'] }),
    club('Getafe', 'ESP', { stadium: 'Coliseum', rep: 70, colors: ['#005ba4', '#ffffff'] }),
    club('Osasuna', 'ESP', { stadium: 'El Sadar', rep: 71, colors: ['#c8102e', '#0b1642'] }),
    club('Espanyol', 'ESP', { stadium: 'RCDE Stadium', rep: 68, colors: ['#0057b8', '#ffffff'] }),
    club('Rayo Vallecano', 'ESP', { stadium: 'Vallecas', rep: 70, colors: ['#c8102e', '#ffffff'] }),
    club('Alavés', 'ESP', { stadium: 'Mendizorrotza', rep: 67, colors: ['#003399', '#ffffff'] }),
    club('Elche', 'ESP', { stadium: 'Martínez Valero', rep: 66, colors: ['#046a38', '#ffffff'] }),
    club('Levante', 'ESP', { stadium: 'Ciutat de València', rep: 67, colors: ['#00285e', '#c8102e'] }),
    club('Racing de Santander', 'ESP', { stadium: 'El Sardinero', rep: 65, colors: ['#00944d', '#ffffff'] }),
    club('Deportivo de La Coruña', 'ESP', { stadium: 'Abanca-Riazor', rep: 66, colors: ['#0057b8', '#ffffff'] }),
    club('Málaga', 'ESP', { stadium: 'La Rosaleda', rep: 64, colors: ['#0057b8', '#ffffff'] }),

    // ===================== ITÁLIA — Serie A 2026-27 (20 clubes) =====================
    club('Inter de Milão', 'ITA', { stadium: 'San Siro', rep: 88, colors: ['#0068a8', '#000000'] }),
    club('Napoli', 'ITA', { stadium: 'Diego Armando Maradona', rep: 84, colors: ['#12a0d7', '#003c71'] }),
    club('Juventus', 'ITA', { stadium: 'Allianz Stadium', rep: 83, colors: ['#000000', '#ffffff'] }),
    club('AC Milan', 'ITA', { stadium: 'San Siro', rep: 82, colors: ['#fb090b', '#000000'] }),
    club('AS Roma', 'ITA', { stadium: 'Stadio Olimpico', rep: 80, colors: ['#960a3d', '#f0bc42'] }),
    club('Atalanta', 'ITA', { stadium: 'Gewiss Stadium', rep: 80, colors: ['#1e71b8', '#000000'] }),
    club('Bologna', 'ITA', { stadium: "Renato Dall'Ara", rep: 77, colors: ['#c8102e', '#0b1642'] }),
    club('Lazio', 'ITA', { stadium: 'Stadio Olimpico', rep: 78, colors: ['#a3d5f7', '#ffffff'] }),
    club('Fiorentina', 'ITA', { stadium: 'Artemio Franchi', rep: 76, colors: ['#663399', '#ffffff'] }),
    club('Udinese', 'ITA', { stadium: 'Bluenergy Stadium', rep: 70, colors: ['#000000', '#ffffff'] }),
    club('Torino', 'ITA', { stadium: 'Stadio Olimpico Grande Torino', rep: 71, colors: ['#7b1e3c', '#ffffff'] }),
    club('Genoa', 'ITA', { stadium: 'Luigi Ferraris', rep: 68, colors: ['#c8102e', '#0b1642'] }),
    club('Como', 'ITA', { stadium: 'Giuseppe Sinigaglia', rep: 71, colors: ['#0057b8', '#ffffff'] }),
    club('Cagliari', 'ITA', { stadium: 'Unipol Domus', rep: 67, colors: ['#c8102e', '#0b1642'] }),
    club('Lecce', 'ITA', { stadium: 'Via del Mare', rep: 65, colors: ['#ffe667', '#c8102e'] }),
    club('Parma', 'ITA', { stadium: 'Ennio Tardini', rep: 66, colors: ['#f4d03f', '#003399'] }),
    club('Sassuolo', 'ITA', { stadium: 'Mapei Stadium', rep: 68, colors: ['#00944d', '#000000'] }),
    club('Venezia', 'ITA', { stadium: 'Pier Luigi Penzo', rep: 62, colors: ['#ff7f00', '#000000'] }),
    club('Frosinone', 'ITA', { stadium: 'Benito Stirpe', rep: 60, colors: ['#ffe667', '#003399'] }),
    club('Monza', 'ITA', { stadium: 'U-Power Stadium', rep: 63, colors: ['#c8102e', '#ffffff'] }),

    // ===================== ALEMANHA — Bundesliga 2026-27 (18 clubes) =====================
    club('Bayern de Munique', 'GER', { stadium: 'Allianz Arena', rep: 90, colors: ['#dc052d', '#0066b2'] }),
    club('Borussia Dortmund', 'GER', { stadium: 'Signal Iduna Park', rep: 82, colors: ['#fde100', '#000000'] }),
    club('Bayer Leverkusen', 'GER', { stadium: 'BayArena', rep: 82, colors: ['#e32221', '#000000'] }),
    club('RB Leipzig', 'GER', { stadium: 'Red Bull Arena', rep: 80, colors: ['#dd0741', '#ffffff'] }),
    club('Eintracht Frankfurt', 'GER', { stadium: 'Deutsche Bank Park', rep: 77, colors: ['#e1000f', '#000000'] }),
    club('VfB Stuttgart', 'GER', { stadium: 'MHPArena', rep: 77, colors: ['#ffffff', '#e32219'] }),
    club('Borussia Mönchengladbach', 'GER', { stadium: 'Borussia-Park', rep: 73, colors: ['#000000', '#ffffff'] }),
    club('1. FC Köln', 'GER', { stadium: 'RheinEnergieStadion', rep: 68, colors: ['#c8102e', '#ffffff'] }),
    club('Werder Bremen', 'GER', { stadium: 'Weserstadion', rep: 71, colors: ['#1d9053', '#ffffff'] }),
    club('Mainz 05', 'GER', { stadium: 'Mewa Arena', rep: 70, colors: ['#c8102e', '#ffffff'] }),
    club('Union Berlin', 'GER', { stadium: 'Stadion An der Alten Försterei', rep: 71, colors: ['#eb1923', '#ffe667'] }),
    club('SC Freiburg', 'GER', { stadium: 'Europa-Park Stadion', rep: 73, colors: ['#000000', '#ffffff'] }),
    club('FC Augsburg', 'GER', { stadium: 'WWK Arena', rep: 68, colors: ['#c8102e', '#046a38'] }),
    club('TSG Hoffenheim', 'GER', { stadium: 'PreZero Arena', rep: 69, colors: ['#1c63b7', '#ffffff'] }),
    club('Hamburger SV', 'GER', { stadium: 'Volksparkstadion', rep: 68, colors: ['#003399', '#ffffff'] }),
    club('FC Schalke 04', 'GER', { stadium: 'Veltins-Arena', rep: 66, colors: ['#004b9b', '#ffffff'] }),
    club('SV Elversberg', 'GER', { stadium: 'URSAPHARM-Arena', rep: 58, colors: ['#003399', '#ffffff'] }),
    club('SC Paderborn 07', 'GER', { stadium: 'Home Deluxe Arena', rep: 60, colors: ['#003399', '#ffffff'] }),

    // ===================== FRANÇA — Ligue 1 2026-27 (18 clubes) =====================
    club('Paris Saint-Germain', 'FRA', { stadium: 'Parc des Princes', rep: 88, colors: ['#004170', '#da291c'] }),
    club('AS Monaco', 'FRA', { stadium: 'Stade Louis II', rep: 79, colors: ['#c8102e', '#ffffff'] }),
    club('Olympique de Marselha', 'FRA', { stadium: 'Stade Vélodrome', rep: 79, colors: ['#2fa4de', '#ffffff'] }),
    club('LOSC Lille', 'FRA', { stadium: 'Stade Pierre-Mauroy', rep: 77, colors: ['#c8102e', '#0b1a40'] }),
    club('RC Lens', 'FRA', { stadium: 'Stade Bollaert-Delelis', rep: 75, colors: ['#ffcc00', '#c8102e'] }),
    club('Olympique Lyonnais', 'FRA', { stadium: 'Groupama Stadium', rep: 76, colors: ['#c8102e', '#003399'] }),
    club('OGC Nice', 'FRA', { stadium: 'Allianz Riviera', rep: 73, colors: ['#c8102e', '#000000'] }),
    club('RC Strasbourg', 'FRA', { stadium: 'Stade de la Meinau', rep: 71, colors: ['#0057b8', '#ffffff'] }),
    club('Stade Rennais FC', 'FRA', { stadium: 'Roazhon Park', rep: 73, colors: ['#c8102e', '#000000'] }),
    club('Stade Brestois 29', 'FRA', { stadium: 'Stade Francis-Le Blé', rep: 68, colors: ['#c8102e', '#ffffff'] }),
    club('AJ Auxerre', 'FRA', { stadium: 'Stade Abbé-Deschamps', rep: 65, colors: ['#003399', '#ffffff'] }),
    club('Toulouse FC', 'FRA', { stadium: 'Stadium de Toulouse', rep: 66, colors: ['#663399', '#ffffff'] }),
    club('Angers SCO', 'FRA', { stadium: 'Stade Raymond-Kopa', rep: 62, colors: ['#000000', '#ffffff'] }),
    club('Le Havre AC', 'FRA', { stadium: 'Stade Océane', rep: 63, colors: ['#0057b8', '#ffffff'] }),
    club('FC Lorient', 'FRA', { stadium: 'Stade du Moustoir', rep: 64, colors: ['#ff7f00', '#000000'] }),
    club('Paris FC', 'FRA', { stadium: 'Stade Jean-Bouin', rep: 65, colors: ['#003399', '#c8102e'] }),
    club('Le Mans FC', 'FRA', { stadium: 'Stade Marie-Marvingt', rep: 58, colors: ['#003399', '#ffffff'] }),
    club('ESTAC Troyes', 'FRA', { stadium: "Stade de l'Aube", rep: 60, colors: ['#0057b8', '#ffffff'] }),

    // ===================== PORTUGAL — Primeira Liga 2026-27 (18 clubes) =====================
    club('FC Porto', 'POR', { stadium: 'Estádio do Dragão', rep: 83, colors: ['#00447c', '#ffffff'] }),
    club('Benfica', 'POR', { stadium: 'Estádio da Luz', rep: 83, colors: ['#c8102e', '#ffffff'] }),
    club('Sporting CP', 'POR', { stadium: 'José Alvalade', rep: 82, colors: ['#ffffff', '#00843d'] }),
    club('SC Braga', 'POR', { stadium: 'Municipal de Braga', rep: 76, colors: ['#c8102e', '#ffffff'] }),
    club('Vitória de Guimarães', 'POR', { stadium: 'D. Afonso Henriques', rep: 72, colors: ['#ffffff', '#000000'] }),
    club('Famalicão', 'POR', { stadium: 'Municipal de Famalicão', rep: 68, colors: ['#c8102e', '#ffffff'] }),
    club('Moreirense', 'POR', { stadium: 'Comendador Joaquim de Almeida Freitas', rep: 64, colors: ['#046a38', '#ffffff'] }),
    club('Gil Vicente', 'POR', { stadium: 'Cidade de Barcelos', rep: 65, colors: ['#c8102e', '#ffffff'] }),
    club('Arouca', 'POR', { stadium: 'Municipal de Arouca', rep: 67, colors: ['#f4d03f', '#000000'] }),
    club('Casa Pia', 'POR', { stadium: 'Municipal de Rio Maior', rep: 63, colors: ['#046a38', '#ffffff'] }),
    club('Estoril Praia', 'POR', { stadium: 'António Coimbra da Mota', rep: 65, colors: ['#f4d03f', '#003399'] }),
    club('Estrela da Amadora', 'POR', { stadium: 'José Gomes', rep: 62, colors: ['#c8102e', '#000000'] }),
    club('Rio Ave', 'POR', { stadium: 'dos Arcos', rep: 64, colors: ['#046a38', '#ffffff'] }),
    club('Santa Clara', 'POR', { stadium: 'de São Miguel', rep: 63, colors: ['#046a38', '#ffffff'] }),
    club('Nacional', 'POR', { stadium: 'da Madeira', rep: 62, colors: ['#000000', '#ffe667'] }),
    club('Alverca', 'POR', { stadium: 'Complexo Desportivo FC Alverca', rep: 61, colors: ['#003399', '#ffffff'] }),
    club('Marítimo', 'POR', { stadium: 'dos Barreiros', rep: 61, colors: ['#046a38', '#ffffff'] }),
    club('Académico de Viseu', 'POR', { stadium: 'Municipal do Fontelo', rep: 58, colors: ['#003399', '#ffffff'] }),

    // ===================== HOLANDA — Eredivisie 2026-27 (18 clubes) =====================
    club('Ajax', 'NED', { stadium: 'Johan Cruyff Arena', rep: 80, colors: ['#d2122e', '#ffffff'] }),
    club('PSV Eindhoven', 'NED', { stadium: 'Philips Stadion', rep: 82, colors: ['#ed1c24', '#ffffff'] }),
    club('Feyenoord', 'NED', { stadium: 'De Kuip', rep: 79, colors: ['#c8102e', '#000000'] }),
    club('AZ Alkmaar', 'NED', { stadium: 'AFAS Stadion', rep: 75, colors: ['#c8102e', '#ffffff'] }),
    club('FC Twente', 'NED', { stadium: 'De Grolsch Veste', rep: 74, colors: ['#c8102e', '#ffffff'] }),
    club('FC Utrecht', 'NED', { stadium: 'Stadion Galgenwaard', rep: 71, colors: ['#c8102e', '#ffffff'] }),
    club('Go Ahead Eagles', 'NED', { stadium: 'De Adelaarshorst', rep: 65, colors: ['#c8102e', '#ffe667'] }),
    club('FC Groningen', 'NED', { stadium: 'Euroborg', rep: 66, colors: ['#046a38', '#ffffff'] }),
    club('SC Heerenveen', 'NED', { stadium: 'Abe Lenstra Stadion', rep: 65, colors: ['#003399', '#ffffff'] }),
    club('Sparta Rotterdam', 'NED', { stadium: 'Het Kasteel', rep: 62, colors: ['#c8102e', '#ffffff'] }),
    club('Fortuna Sittard', 'NED', { stadium: 'Fortuna Sittard Stadion', rep: 60, colors: ['#f4d03f', '#046a38'] }),
    club('NEC Nijmegen', 'NED', { stadium: 'Goffertstadion', rep: 63, colors: ['#c8102e', '#000000'] }),
    club('PEC Zwolle', 'NED', { stadium: 'MAC³PARK Stadion', rep: 61, colors: ['#003399', '#ffffff'] }),
    club('Excelsior', 'NED', { stadium: 'Van Donge & De Roo Stadion', rep: 58, colors: ['#c8102e', '#000000'] }),
    club('Telstar', 'NED', { stadium: 'Rabobank IJmond Stadion', rep: 56, colors: ['#046a38', '#ffffff'] }),
    club('ADO Den Haag', 'NED', { stadium: 'Bingoal Stadion', rep: 58, colors: ['#046a38', '#ffe667'] }),
    club('SC Cambuur', 'NED', { stadium: 'Cambuur Stadion', rep: 59, colors: ['#003399', '#ffe667'] }),
    club('Willem II', 'NED', { stadium: 'Koning Willem II Stadion', rep: 57, colors: ['#c8102e', '#ffffff'] }),

    // ===================== OUTROS PAÍSES — só para dar profundidade às competições
    // continentais (Libertadores/Sul-Americana/Champions/Europa); não têm liga
    // doméstica simulada neste jogo. =====================
    club('Peñarol', 'URU', { stadium: 'Campeón del Siglo', rep: 74, colors: ['#f4d03f', '#000000'] }),
    club('Nacional de Montevideo', 'URU', { stadium: 'Gran Parque Central', rep: 73, colors: ['#ffffff', '#003399'] }),
    club('Danubio', 'URU', { stadium: 'Jardines del Hipódromo', rep: 60, colors: ['#003399', '#ffffff'] }),
    club('Defensor Sporting', 'URU', { stadium: 'Luis Franzini', rep: 61, colors: ['#663399', '#ffffff'] }),
    club('Millonarios', 'COL', { stadium: 'El Campín', rep: 68, colors: ['#003399', '#ffffff'] }),
    club('Atlético Nacional', 'COL', { stadium: 'Atanasio Girardot', rep: 71, colors: ['#046a38', '#ffffff'] }),
    club('América de Cali', 'COL', { stadium: 'Pascual Guerrero', rep: 66, colors: ['#c8102e', '#ffffff'] }),
    club('Junior de Barranquilla', 'COL', { stadium: 'Metropolitano', rep: 65, colors: ['#c8102e', '#ffffff'] }),
    club('Colo-Colo', 'CHI', { stadium: 'Monumental David Arellano', rep: 70, colors: ['#000000', '#ffffff'] }),
    club('Universidad de Chile', 'CHI', { stadium: 'Nacional Julio Martínez Prádanos', rep: 68, colors: ['#003399', '#ffffff'] }),
    club('Universidad Católica', 'CHI', { stadium: 'San Carlos de Apoquindo', rep: 67, colors: ['#663399', '#ffffff'] }),
    club('Palestino', 'CHI', { stadium: 'Municipal de La Cisterna', rep: 58, colors: ['#c8102e', '#046a38'] }),
    club('Olimpia', 'PAR', { stadium: 'Manuel Ferreira', rep: 69, colors: ['#000000', '#ffffff'] }),
    club('Cerro Porteño', 'PAR', { stadium: 'General Pablo Rojas', rep: 67, colors: ['#c8102e', '#003399'] }),
    club('Libertad', 'PAR', { stadium: 'Dr. Nicolás Leoz', rep: 62, colors: ['#046a38', '#ffffff'] }),
    club('Barcelona SC', 'ECU', { stadium: 'Monumental Banco Pichincha', rep: 68, colors: ['#f4d03f', '#c8102e'] }),
    club('LDU Quito', 'ECU', { stadium: 'Rodrigo Paz Delgado', rep: 67, colors: ['#ffffff', '#003399'] }),
    club('Emelec', 'ECU', { stadium: 'George Capwell', rep: 63, colors: ['#003399', '#c8102e'] }),
    club('Independiente del Valle', 'ECU', { stadium: 'Banco Guayaquil', rep: 64, colors: ['#000000', '#ffffff'] }),
    club('Universitario', 'PER', { stadium: 'Monumental U', rep: 66, colors: ['#c8102e', '#ffffff'] }),
    club('Alianza Lima', 'PER', { stadium: 'Alejandro Villanueva', rep: 65, colors: ['#003399', '#ffffff'] }),
    club('Sporting Cristal', 'PER', { stadium: 'Alberto Gallardo', rep: 63, colors: ['#003399', '#ffffff'] }),

    club('Club Brugge', 'BEL', { stadium: 'Jan Breydel Stadion', rep: 74, colors: ['#003399', '#000000'] }),
    club('Anderlecht', 'BEL', { stadium: 'Lotto Park', rep: 71, colors: ['#663399', '#ffffff'] }),
    club('Union Saint-Gilloise', 'BEL', { stadium: 'Stade Joseph Marien', rep: 68, colors: ['#ffe667', '#003399'] }),
    club('Genk', 'BEL', { stadium: 'Cegeka Arena', rep: 66, colors: ['#003399', '#ffffff'] }),
    club('Celtic', 'SCO', { stadium: 'Celtic Park', rep: 75, colors: ['#046a38', '#ffffff'] }),
    club('Rangers', 'SCO', { stadium: 'Ibrox Stadium', rep: 73, colors: ['#003399', '#ffffff'] }),
    club('Galatasaray', 'TUR', { stadium: 'Rams Park', rep: 76, colors: ['#c8102e', '#ffe667'] }),
    club('Fenerbahçe', 'TUR', { stadium: 'Şükrü Saracoğlu', rep: 75, colors: ['#ffe667', '#003399'] }),
    club('Beşiktaş', 'TUR', { stadium: 'Vodafone Park', rep: 72, colors: ['#000000', '#ffffff'] }),
    club('Olympiacos', 'GRE', { stadium: 'Karaiskakis', rep: 73, colors: ['#c8102e', '#ffffff'] }),
    club('Panathinaikos', 'GRE', { stadium: 'Apostolos Nikolaidis', rep: 68, colors: ['#046a38', '#ffffff'] }),
    club('AEK Athens', 'GRE', { stadium: 'Agia Sofia', rep: 66, colors: ['#ffe667', '#000000'] }),
    club('Young Boys', 'SUI', { stadium: 'Stade de Suisse', rep: 70, colors: ['#ffe667', '#000000'] }),
    club('FC Basel', 'SUI', { stadium: 'St. Jakob-Park', rep: 69, colors: ['#c8102e', '#003399'] }),
    club('Red Bull Salzburg', 'AUT', { stadium: 'Red Bull Arena', rep: 73, colors: ['#c8102e', '#ffffff'] }),
    club('Rapid Wien', 'AUT', { stadium: 'Allianz Stadion', rep: 66, colors: ['#046a38', '#ffffff'] }),
    club('Dinamo Zagreb', 'CRO', { stadium: 'Maksimir', rep: 71, colors: ['#003399', '#ffffff'] }),
    club('Hajduk Split', 'CRO', { stadium: 'Poljud', rep: 66, colors: ['#ffffff', '#003399'] }),
    club('Shakhtar Donetsk', 'UKR', { stadium: 'Arena Lviv', rep: 73, colors: ['#ff7f00', '#000000'] }),
    club('Dynamo Kyiv', 'UKR', { stadium: 'Valeriy Lobanovskyi', rep: 69, colors: ['#003399', '#ffffff'] }),
    club('FC Copenhagen', 'DEN', { stadium: 'Parken', rep: 70, colors: ['#ffffff', '#003399'] }),
    club('Brøndby', 'DEN', { stadium: 'Brøndby Stadion', rep: 65, colors: ['#ffe667', '#003399'] }),
    club('Sparta Prague', 'CZE', { stadium: 'Letná', rep: 68, colors: ['#c8102e', '#000000'] }),
    club('Slavia Prague', 'CZE', { stadium: 'Eden Aréna', rep: 69, colors: ['#c8102e', '#ffffff'] }),
  ];

  function getCrest(clubObj) {
    if (crestCache[clubObj.id]) return { remote: crestCache[clubObj.id], fallback: monogramSVG(clubObj.name, clubObj.colors[0], clubObj.colors[1]) };
    const url = crestUrl(clubObj);
    return { remote: url || '', fallback: monogramSVG(clubObj.name, clubObj.colors[0], clubObj.colors[1]) };
  }

  // National teams as pseudo-clubs — enough shape (name/reputation/colors)
  // to reuse the same match engine and crest helpers as club football.
  const NATION_REPUTATION = {
    Espanha: 91, Argentina: 89, França: 88, Inglaterra: 86, Brasil: 85, Portugal: 84,
    Alemanha: 83, Holanda: 82, Itália: 80, Bélgica: 79, Croácia: 76, Uruguai: 78,
    Colômbia: 76, México: 76, 'Estados Unidos': 74, Japão: 74, Marrocos: 77, Senegal: 74,
    Chile: 70, Peru: 66, Equador: 70, Paraguai: 68, Bolívia: 60, Venezuela: 66,
    Canadá: 72, Nigéria: 72, 'Coreia do Sul': 71,
  };
  const NATION_ARTICLE = {
    Brasil: 'do Brasil', Argentina: 'da Argentina', Uruguai: 'do Uruguai', Chile: 'do Chile',
    Paraguai: 'do Paraguai', Peru: 'do Peru', Equador: 'do Equador', 'Estados Unidos': 'dos Estados Unidos',
    Japão: 'do Japão', 'Coreia do Sul': 'da Coreia do Sul', México: 'do México', Canadá: 'do Canadá',
  };
  function getNationalTeam(nationality) {
    return {
      id: 'nt_' + slug(nationality), name: `Seleção ${NATION_ARTICLE[nationality] || 'de ' + nationality}`,
      shortName: nationality, isNationalTeam: true,
      reputation: NATION_REPUTATION[nationality] || 60,
      colors: NATION_COLORS[nationality] || ['#1c1c1c', '#3a3a3a'],
    };
  }
  const NATION_COLORS = {
    Brasil: ['#fdd000', '#046a38'], Argentina: ['#75aadb', '#ffffff'], Inglaterra: ['#ffffff', '#c8102e'],
    Espanha: ['#c8102e', '#ffe667'], Itália: ['#003399', '#ffffff'], Alemanha: ['#000000', '#ffffff'],
    França: ['#003399', '#c8102e'], Portugal: ['#c8102e', '#046a38'], Holanda: ['#ff7f00', '#003399'],
  };
  function getFlagCrest(nationality) {
    const url = flagUrl(nationality);
    return { remote: url || '', fallback: monogramSVG(nationality, '#1c1c1c', '#3a3a3a') };
  }

  // Continental club competitions — only modeled for confederations that
  // actually have leagues in-game (CONMEBOL: BRA+ARG, UEFA: the 7 European
  // leagues). Eligibility is by club reputation percentile within that pool,
  // same simplification the domestic cups already use.
  const CONTINENTAL = {
    CONMEBOL: { top: 'Libertadores', second: 'Sul-Americana', leagues: ['BRA', 'ARG', 'URU', 'COL', 'CHI', 'PAR', 'ECU', 'PER'] },
    UEFA: { top: 'Champions League', second: 'Europa League', leagues: ['ENG', 'ESP', 'ITA', 'GER', 'FRA', 'POR', 'NED', 'BEL', 'SCO', 'TUR', 'GRE', 'SUI', 'AUT', 'CRO', 'UKR', 'DEN', 'CZE'] },
  };
  function continentalFor(leagueCode) {
    return Object.values(CONTINENTAL).find(c => c.leagues.includes(leagueCode)) || null;
  }

  // ---------------------------------------------------------------------
  // SPONSORS — real global sportswear / tech / energy brands
  // ---------------------------------------------------------------------
  const SPONSORS = [
    { name: 'Nike', type: 'Material Esportivo', tier: 3, color: '#111111', domain: 'nike.com' },
    { name: 'Adidas', type: 'Material Esportivo', tier: 3, color: '#000000', domain: 'adidas.com' },
    { name: 'Puma', type: 'Material Esportivo', tier: 2, color: '#000000', domain: 'puma.com' },
    { name: 'New Balance', type: 'Material Esportivo', tier: 2, color: '#c8102e', domain: 'newbalance.com' },
    { name: 'Umbro', type: 'Material Esportivo', tier: 1, color: '#0b1642', domain: 'umbro.com' },
    { name: 'Mizuno', type: 'Material Esportivo', tier: 1, color: '#0033a0', domain: 'mizuno.com' },
    { name: 'Under Armour', type: 'Material Esportivo', tier: 2, color: '#c8102e', domain: 'underarmour.com' },
    { name: 'Red Bull', type: 'Energético', tier: 3, color: '#1b1f8a', domain: 'redbull.com' },
    { name: 'Monster Energy', type: 'Energético', tier: 2, color: '#0a8a3c', domain: 'monsterenergy.com' },
    { name: 'EA Sports', type: 'Entretenimento', tier: 3, color: '#e2231a', domain: 'ea.com' },
    { name: 'Oakley', type: 'Acessórios', tier: 1, color: '#e2231a', domain: 'oakley.com' },
    { name: 'HyperX', type: 'Tecnologia', tier: 1, color: '#e2231a', domain: 'hyperx.com' },
    { name: 'Samsung', type: 'Tecnologia', tier: 3, color: '#1428a0', domain: 'samsung.com' },
    { name: 'Apple', type: 'Tecnologia', tier: 3, color: '#555555', domain: 'apple.com' },
    { name: 'Sony', type: 'Tecnologia', tier: 2, color: '#000000', domain: 'sony.com' },
  ];
  function getSponsorLogo(sponsor) {
    return { remote: `https://logo.clearbit.com/${sponsor.domain}`, fallback: monogramSVG(sponsor.name, sponsor.color, sponsor.color) };
  }

  // ---------------------------------------------------------------------
  // NAME POOLS
  // ---------------------------------------------------------------------
  const NAME_POOLS = {
    Brasil: {
      first: ['Gabriel', 'Lucas', 'Matheus', 'Bruno', 'Rafael', 'Pedro', 'Vinícius', 'Kaique', 'Thiago', 'Everton', 'Wesley', 'Anderson', 'Cauã', 'Igor', 'Yuri', 'Erick', 'Douglas', 'Ryan', 'Emerson', 'Marcelo'],
      last: ['Silva', 'Souza', 'Santos', 'Oliveira', 'Pereira', 'Costa', 'Almeida', 'Ferreira', 'Rodrigues', 'Carvalho', 'Gomes', 'Martins', 'Araújo', 'Barbosa', 'Ribeiro', 'Nascimento', 'Cardoso', 'Teixeira'],
    },
    Argentina: {
      first: ['Lautaro', 'Enzo', 'Julián', 'Nicolás', 'Franco', 'Thiago', 'Valentín', 'Agustín', 'Ezequiel', 'Máximo', 'Ignacio', 'Bautista'],
      last: ['González', 'Rodríguez', 'Fernández', 'López', 'Martínez', 'Díaz', 'Pérez', 'Sánchez', 'Romero', 'Álvarez', 'Torres', 'Ruiz'],
    },
    Inglaterra: {
      first: ['Jack', 'Harry', 'Oliver', 'George', 'Charlie', 'Jacob', 'Alfie', 'Freddie', 'Archie', 'Tyler', 'Callum', 'Ethan'],
      last: ['Smith', 'Jones', 'Taylor', 'Brown', 'Wilson', 'Evans', 'Thomas', 'Roberts', 'Walker', 'Wright', 'Baker', 'Harris'],
    },
    Espanha: {
      first: ['Alejandro', 'Pablo', 'Álvaro', 'Marc', 'Iker', 'Hugo', 'Mario', 'Sergio', 'Adrián', 'Diego', 'Rodrigo', 'Nico'],
      last: ['García', 'Martín', 'López', 'González', 'Fernández', 'Muñoz', 'Navarro', 'Torres', 'Domínguez', 'Vázquez', 'Ramos', 'Gil'],
    },
    Itália: {
      first: ['Matteo', 'Lorenzo', 'Andrea', 'Francesco', 'Marco', 'Davide', 'Riccardo', 'Gianluca', 'Federico', 'Simone', 'Alessandro'],
      last: ['Rossi', 'Russo', 'Ferrari', 'Esposito', 'Bianchi', 'Romano', 'Colombo', 'Ricci', 'Marino', 'Greco', 'Bruno', 'Gallo'],
    },
    Alemanha: {
      first: ['Maximilian', 'Leon', 'Finn', 'Jonas', 'Elias', 'Paul', 'Luca', 'Noah', 'Felix', 'Julian', 'Tim'],
      last: ['Müller', 'Schmidt', 'Schneider', 'Fischer', 'Weber', 'Meyer', 'Wagner', 'Becker', 'Hoffmann', 'Koch', 'Richter'],
    },
    França: {
      first: ['Hugo', 'Léo', 'Nathan', 'Enzo', 'Louis', 'Gabriel', 'Mohamed', 'Yanis', 'Rayan', 'Mathis', 'Kylian'],
      last: ['Martin', 'Bernard', 'Dubois', 'Thomas', 'Robert', 'Petit', 'Durand', 'Leroy', 'Moreau', 'Simon', 'Laurent'],
    },
    Portugal: {
      first: ['João', 'Rúben', 'Gonçalo', 'Diogo', 'Francisco', 'Tiago', 'Rafael', 'André', 'Bernardo', 'Pedro'],
      last: ['Silva', 'Santos', 'Ferreira', 'Pereira', 'Costa', 'Oliveira', 'Carvalho', 'Rodrigues', 'Martins', 'Sousa'],
    },
    Holanda: {
      first: ['Sem', 'Daan', 'Levi', 'Milan', 'Luuk', 'Bram', 'Thijs', 'Ruben', 'Sven', 'Noud'],
      last: ['De Jong', 'Jansen', 'De Vries', 'Van den Berg', 'Bakker', 'Visser', 'Smit', 'Meijer', 'Mulder', 'De Boer'],
    },
    Outra: {
      first: ['Alex', 'Kevin', 'Chris', 'Daniel', 'Erik', 'Marco', 'Sam', 'Tom', 'Leo', 'Max'],
      last: ['Silva', 'Nowak', 'Kowalski', 'Andersen', 'Larsen', 'Novák', 'Horvat', 'Petrov', 'Ivanov', 'Popescu'],
    },
  };

  // ---------------------------------------------------------------------
  // NATIONALITIES + CONFEDERATION MAP — this is what fixes the "Brazil in
  // the Eurocopa" bug: national-team competitions are chosen strictly by
  // the confederation the player's nationality belongs to.
  // ---------------------------------------------------------------------
  const CONFEDERATIONS = {
    CONMEBOL: ['Brasil', 'Argentina', 'Uruguai', 'Colômbia', 'Chile', 'Paraguai', 'Peru', 'Equador', 'Bolívia', 'Venezuela'],
    UEFA: ['Inglaterra', 'Espanha', 'Itália', 'Alemanha', 'França', 'Portugal', 'Holanda', 'Bélgica', 'Croácia'],
    CONCACAF: ['Estados Unidos', 'México', 'Canadá'],
    CAF: ['Nigéria', 'Senegal', 'Marrocos'],
    AFC: ['Japão', 'Coreia do Sul'],
  };

  const NATIONAL_COMPETITIONS_BY_CONFEDERATION = {
    CONMEBOL: ['Eliminatórias Sul-Americanas', 'Copa América', 'Copa do Mundo', 'Amistoso Internacional'],
    UEFA: ['Eliminatórias Europeias', 'Eurocopa', 'Liga das Nações', 'Copa do Mundo', 'Amistoso Internacional'],
    CONCACAF: ['Eliminatórias da CONCACAF', 'Copa Ouro', 'Copa do Mundo', 'Amistoso Internacional'],
    CAF: ['Eliminatórias Africanas', 'Copa Africana de Nações', 'Copa do Mundo', 'Amistoso Internacional'],
    AFC: ['Eliminatórias Asiáticas', 'Copa da Ásia', 'Copa do Mundo', 'Amistoso Internacional'],
  };

  const NATIONALITIES = Object.keys(CONFEDERATIONS).reduce((acc, k) => acc.concat(CONFEDERATIONS[k]), []).concat(['Outra']);

  function confederationOf(nationality) {
    return Object.keys(CONFEDERATIONS).find(k => CONFEDERATIONS[k].includes(nationality)) || null;
  }
  function nationalCompetitionsFor(nationality) {
    const conf = confederationOf(nationality);
    return conf ? NATIONAL_COMPETITIONS_BY_CONFEDERATION[conf] : ['Amistoso Internacional'];
  }

  function randomCoachName(leagueCode) {
    const nat = LEAGUES[leagueCode] ? LEAGUES[leagueCode].country : 'Outra';
    const pool = NAME_POOLS[nat] || NAME_POOLS.Outra;
    return `${pick(pool.first)} ${pick(pool.last)}`;
  }

  function randomPlayerName(nationality) {
    const pool = NAME_POOLS[nationality] || NAME_POOLS.Outra;
    return `${pick(pool.first)} ${pick(pool.last)}`;
  }

  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

  const POSITIONS = ['GOL', 'ZAG', 'LE', 'LD', 'VOL', 'MC', 'MEIA', 'PE', 'PD', 'ATA'];
  const POSITION_NAMES = {
    GOL: 'Goleiro', ZAG: 'Zagueiro', LE: 'Lateral Esquerdo', LD: 'Lateral Direito',
    VOL: 'Volante', MC: 'Meio-campista', MEIA: 'Meia Ofensivo',
    PE: 'Ponta Esquerda', PD: 'Ponta Direita', ATA: 'Atacante',
  };

  // ---------------------------------------------------------------------
  // SCHEDULE / BRACKET GENERATORS — always pre-filtered by caller to a
  // single league/state/zone group, so fixtures never cross competitions.
  // ---------------------------------------------------------------------
  function clubsByLeague(leagueCode) { return CLUBS.filter(c => c.league === leagueCode); }
  function clubsByCountry(country) {
    const code = Object.keys(LEAGUES).find(k => LEAGUES[k].country === country);
    return code ? clubsByLeague(code) : [];
  }
  function clubsByState(leagueCode, state) { return CLUBS.filter(c => c.league === leagueCode && c.state === state); }
  function clubsByZone(leagueCode, zone) { return CLUBS.filter(c => c.league === leagueCode && c.zone === zone); }

  function roundRobinSchedule(clubIds, doubleRound) {
    let ids = clubIds.slice();
    const bye = ids.length % 2 !== 0;
    if (bye) ids.push(null);
    const n = ids.length;
    const rounds = [];
    const fixed = ids[0];
    let rest = ids.slice(1);
    for (let r = 0; r < n - 1; r++) {
      const roundIds = [fixed, ...rest];
      const pairs = [];
      for (let i = 0; i < n / 2; i++) {
        const a = roundIds[i], b = roundIds[n - 1 - i];
        if (a !== null && b !== null) pairs.push(r % 2 === 0 ? { home: a, away: b } : { home: b, away: a });
      }
      rounds.push(pairs);
      rest.unshift(rest.pop());
    }
    if (doubleRound) {
      const secondLeg = rounds.map(round => round.map(m => ({ home: m.away, away: m.home })));
      return rounds.concat(secondLeg);
    }
    return rounds;
  }

  function knockoutBracket(clubIds) {
    const ids = clubIds.slice();
    let size = 2; while (size < ids.length) size *= 2;
    while (ids.length < size) ids.push(null);
    const round1 = [];
    for (let i = 0; i < size / 2; i++) round1.push({ home: ids[i], away: ids[size - 1 - i] });
    return round1;
  }

  function allNationTeamNationalities() { return Object.keys(NATION_REPUTATION); }

  return {
    LEAGUES, ESTADUAIS, CUPS, CLUBS, SPONSORS, NAME_POOLS, NATIONALITIES, POSITIONS,
    POSITION_NAMES, CONFEDERATIONS, CONTINENTAL,
    getCrest, getFlagCrest, getNationalTeam, continentalFor, allNationTeamNationalities, getSponsorLogo, prefetchClubCrests,
    clubsByLeague, clubsByCountry, clubsByState, clubsByZone,
    randomPlayerName, pick, slug, confederationOf, nationalCompetitionsFor,
    roundRobinSchedule, knockoutBracket,
  };
})();
