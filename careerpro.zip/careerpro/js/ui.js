/**
 * ui.js
 * ---------------------------------------------------------------------------
 * All DOM rendering. Pure presentation — game.js drives the flow and calls
 * into Career/Transfers, then re-renders via the functions exported here.
 * ---------------------------------------------------------------------------
 */

const UI = (() => {
  const root = () => document.getElementById('app');

  function crestImg(club, size = 40) {
    if (!club) return '';
    const c = club.isNationalTeam ? DB.getFlagCrest(club.shortName) : DB.getCrest(club);
    return `<img class="crest" width="${size}" height="${size}" src="${c.remote}" onerror="this.onerror=null;this.src='${c.fallback}'" alt="${club.name}">`;
  }

  function attrBar(label, value) {
    return `<div class="attr-row">
      <span class="attr-label">${label}</span>
      <div class="attr-track"><div class="attr-fill" style="width:${value}%"></div></div>
      <span class="attr-val">${value}</span>
    </div>`;
  }

  function statChip(label, value) {
    return `<div class="chip"><span class="chip-val">${value}</span><span class="chip-label">${label}</span></div>`;
  }

  // =========================================================================
  // SCREEN: NEW GAME
  // =========================================================================
  function renderCreatePlayer() {
    const nats = DB.NATIONALITIES.map(n => `<option value="${n}">${n}</option>`).join('');
    const poss = DB.POSITIONS.map(p => `<option value="${p}">${DB.POSITION_NAMES[p]}</option>`).join('');
    root().innerHTML = `
    <div class="screen create-screen fade-in">
      <div class="brand"><span class="brand-mark">⚽</span><h1>CAREER<span>PRO</span></h1></div>
      <p class="tagline">Construa a carreira do seu atleta, do sub-17 ao topo do futebol mundial.</p>
      <form id="createForm" class="card form-card">
        <div class="grid2">
          <label>Nome<input required name="firstName" maxlength="18" placeholder="Ex: Rafael"></label>
          <label>Sobrenome<input required name="lastName" maxlength="18" placeholder="Ex: Andrade"></label>
        </div>
        <div class="grid3">
          <label>Idade
            <select name="age"><option value="16">16 anos</option><option value="17">17 anos</option><option value="18" selected>18 anos</option></select>
          </label>
          <label>Nacionalidade<select name="nationality">${nats}</select></label>
          <label>Pé dominante<select name="foot"><option>Destro</option><option>Canhoto</option><option>Ambidestro</option></select></label>
        </div>
        <div class="grid3">
          <label>Altura (cm)<input required type="number" name="height" min="160" max="205" value="180"></label>
          <label>Peso (kg)<input required type="number" name="weight" min="55" max="100" value="74"></label>
          <label>Posição<select name="position">${poss}</select></label>
        </div>
        <button class="btn-primary" type="submit">Começar carreira</button>
      </form>
    </div>`;
  }

  // =========================================================================
  // SCREEN: OVERALL REVEAL + CLUB PROPOSALS
  // =========================================================================
  function renderClubProposals(player, proposals, leagueChoiceHandler) {
    const p = player;
    let body;
    if (proposals.needsLeagueChoice) {
      const leagues = Object.entries(DB.LEAGUES).map(([code, l]) =>
        `<button class="league-pick" data-league="${code}">${l.flag} ${l.name} <small>${l.country}</small></button>`).join('');
      body = `<p class="muted">Não há liga disponível para ${p.nationality} ainda. Escolha em qual liga você quer começar:</p>
        <div class="league-grid">${leagues}</div>`;
    } else {
      body = `<p class="muted">Três clubes acompanharam sua base e enviaram propostas:</p>
        <div class="proposal-grid">${proposals.clubs.map((c, i) => proposalCard(c, i)).join('')}</div>`;
    }

    root().innerHTML = `
    <div class="screen reveal-screen fade-in">
      <div class="reveal-card card">
        <span class="eyebrow">Novo talento revelado</span>
        <h2>${p.name}</h2>
        <div class="reveal-row">
          <div class="ovr-badge">${p.overall}<small>OVR</small></div>
          <div class="reveal-details">
            <div>${DB.POSITION_NAMES[p.position]} · ${p.age} anos · ${p.nationality}</div>
            <div class="muted small">Potencial estimado: ${p.potential} OVR</div>
          </div>
        </div>
      </div>
      <div class="card">${body}</div>
    </div>`;

    document.querySelectorAll('.league-pick').forEach(btn => btn.addEventListener('click', () => leagueChoiceHandler(btn.dataset.league)));
  }

  function proposalCard(c, i) {
    return `<div class="proposal-card" data-idx="${i}">
      ${crestImg(c, 56)}
      <h3>${c.name}</h3>
      <span class="muted small">${DB.LEAGUES[c.league].name}</span>
      <div class="proposal-meta"><span>⭐ Reputação ${c.reputation}</span><span>🏟️ ${c.stadium}</span></div>
      <button class="btn-primary btn-sm" data-choose="${i}">Assinar contrato</button>
    </div>`;
  }

  function renderClubList(clubs, onChoose) {
    root().querySelector('.card:last-child').innerHTML = `
      <p class="muted">Clubes disponíveis nesta liga:</p>
      <div class="proposal-grid">${clubs.map((c, i) => proposalCard(c, i)).join('')}</div>`;
    root().querySelectorAll('[data-choose]').forEach(btn =>
      btn.addEventListener('click', () => onChoose(clubs[parseInt(btn.dataset.choose)])));
  }

  // =========================================================================
  // END-OF-CONTRACT SCREEN — renew with the current club, or pick a league
  // and negotiate with one of the clubs interested in signing the player.
  // =========================================================================
  function renderContractDecision(state, renewalOffer, onDone) {
    const p = state.player;
    root().innerHTML = `
    <div class="screen reveal-screen fade-in">
      <div class="reveal-card card">
        <span class="eyebrow">${renewalOffer ? 'Fim de contrato' : 'Agente livre'}</span>
        <h2>${p.name}</h2>
        <p class="muted">${renewalOffer ? `Seu vínculo com o ${state.club.name} chegou ao fim. Hora de decidir o futuro da carreira.` : `Você está livre no mercado. Hora de escolher o próximo destino.`}</p>
      </div>
      ${renewalOffer ? `<div class="card">
        <h3>Renovar com ${state.club.name}</h3>
        <div class="stat-row">
          ${statChip('Salário/sem', Career.formatMoney(renewalOffer.wageWeekly))}${statChip('Anos', renewalOffer.years)}
          ${statChip('Luvas', Career.formatMoney(renewalOffer.signingBonus))}
        </div>
        <button class="btn-primary" id="btnRenew">Assinar renovação</button>
      </div>` : ''}
      <div class="card" id="newClubCard">
        <h3>Ou procure um novo desafio</h3>
        <p class="muted small">Escolha uma liga para ver quem tem interesse em te contratar:</p>
        <div class="league-grid">${Object.entries(DB.LEAGUES).map(([code, l]) =>
      `<button class="league-pick" data-league="${code}">${l.flag} ${l.name} <small>${l.country}</small></button>`).join('')}</div>
      </div>
    </div>`;

    if (renewalOffer) {
      document.getElementById('btnRenew').addEventListener('click', () => {
        Career.renewContract(renewalOffer);
        onDone();
      });
    }
    wireLeaguePicks();

    function wireLeaguePicks() {
      document.querySelectorAll('.league-pick').forEach(btn => btn.addEventListener('click', () => showInterestedClubs(btn.dataset.league)));
    }

    function showInterestedClubs(leagueCode) {
      const clubs = Career.getInterestedClubs(leagueCode);
      const card = document.getElementById('newClubCard');
      if (!clubs.length) {
        card.innerHTML = `<h3>Ou procure um novo desafio</h3><p class="warn small">Nenhum clube dessa liga demonstrou interesse no momento.</p><button class="btn-secondary btn-sm" id="btnBackLeagues">← Escolher outra liga</button>`;
        document.getElementById('btnBackLeagues').addEventListener('click', renderLeaguePicker);
        return;
      }
      card.innerHTML = `<h3>Clubes interessados</h3>
        <div class="proposal-grid">${clubs.map((c, i) => proposalCard(c, i)).join('')}</div>
        <button class="btn-secondary btn-sm" id="btnBackLeagues">← Escolher outra liga</button>`;
      card.querySelectorAll('[data-choose]').forEach(b => b.addEventListener('click', () => showNegotiation(clubs[parseInt(b.dataset.choose)])));
      document.getElementById('btnBackLeagues').addEventListener('click', renderLeaguePicker);
    }

    function renderLeaguePicker() {
      const card = document.getElementById('newClubCard');
      card.innerHTML = `<h3>Ou procure um novo desafio</h3>
        <p class="muted small">Escolha uma liga para ver quem tem interesse em te contratar:</p>
        <div class="league-grid">${Object.entries(DB.LEAGUES).map(([code, l]) =>
        `<button class="league-pick" data-league="${code}">${l.flag} ${l.name} <small>${l.country}</small></button>`).join('')}</div>`;
      wireLeaguePicks();
    }

    function showNegotiation(club) {
      let offer = Career.getClubOffer(club);
      const card = document.getElementById('newClubCard');
      const render = () => {
        card.innerHTML = `<h3>Proposta do ${club.name}</h3>
          <div class="stat-row">
            ${statChip('Salário/sem', Career.formatMoney(offer.wageWeekly))}${statChip('Anos', offer.years)}
            ${statChip('Luvas', Career.formatMoney(offer.signingBonus))}${statChip('Cláusula', Career.formatMoney(offer.releaseClause))}
          </div>
          <div class="negotiate-row">
            <button class="btn-ghost" data-neg="wage">Pedir salário maior</button>
            <button class="btn-ghost" data-neg="years-down">Reduzir anos</button>
            <button class="btn-ghost" data-neg="clause">Elevar cláusula</button>
          </div>
          <div class="btn-row">
            <button class="btn-primary" id="btnSign">Assinar contrato</button>
            <button class="btn-secondary btn-sm" id="btnBackClubs">← Voltar</button>
          </div>`;
        card.querySelectorAll('[data-neg]').forEach(b => b.addEventListener('click', () => {
          const kind = b.dataset.neg;
          const field = kind === 'wage' ? 'wageWeekly' : kind === 'years-down' ? 'years' : 'releaseClause';
          const dir = kind === 'years-down' ? -1 : 1;
          const updated = Transfers.negotiate(offer, field, dir);
          const evalRes = Transfers.evaluateCounterOffer(offer, updated);
          if (evalRes.accepted) offer = updated;
          alert(evalRes.reaction);
          render();
        }));
        document.getElementById('btnSign').addEventListener('click', () => { Career.signWithNewClub(club, offer); onDone(); });
        document.getElementById('btnBackClubs').addEventListener('click', () => showInterestedClubs(club.league));
      };
      render();
    }
  }

  // =========================================================================
  // MAIN HUB
  // =========================================================================
  let activeTab = 'inicio';

  function renderHub(state) {
    root().innerHTML = `
    <div class="hub">
      ${renderTopbar(state)}
      <div class="hub-body">
        <nav class="tabs">
          ${tabBtn('inicio', '🏠 Início')}${tabBtn('atleta', '🧑 Atleta')}
          ${tabBtn('elenco', '👥 Elenco')}${tabBtn('calendario', '📅 Calendário')}
          ${tabBtn('competicoes', '🏆 Competições')}${tabBtn('premios', '🥇 Prêmios')}
          ${tabBtn('clube', '🏛️ Clube')}${tabBtn('treino', '🏋️ Treino')}${tabBtn('imprensa', '📰 Imprensa')}
        </nav>
        <div class="tab-content fade-in" id="tabContent"></div>
      </div>
    </div>`;
    document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => {
      activeTab = btn.dataset.tab;
      document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === activeTab));
      renderTab(state);
    }));
    renderTab(state);
  }

  function tabBtn(key, label) { return `<button class="tab ${activeTab === key ? 'active' : ''}" data-tab="${key}">${label}</button>`; }

  function renderTopbar(state) {
    const p = state.player;
    const [c1] = state.club.colors || ['#111', '#222'];
    return `<header class="topbar" style="--club-accent:${c1}">
      <div class="topbar-club">${crestImg(state.club, 32)}<span>${state.club.name}</span></div>
      <div class="topbar-player"><span class="topbar-name">${p.name}</span><span class="topbar-ovr">${p.overall} OVR</span></div>
      <div class="topbar-year">📅 ${state.year}</div>
    </header>`;
  }

  function renderTab(state) {
    const el = document.getElementById('tabContent');
    if (!el) return;
    el.classList.remove('fade-in'); void el.offsetWidth; el.classList.add('fade-in');
    if (activeTab === 'inicio') el.innerHTML = tplInicio(state);
    if (activeTab === 'atleta') el.innerHTML = tplAtleta(state);
    if (activeTab === 'elenco') el.innerHTML = tplElenco(state);
    if (activeTab === 'calendario') el.innerHTML = tplCalendario(state);
    if (activeTab === 'clube') el.innerHTML = tplClube(state);
    if (activeTab === 'competicoes') el.innerHTML = tplCompeticoes(state);
    if (activeTab === 'premios') el.innerHTML = tplPremios(state);
    if (activeTab === 'treino') el.innerHTML = tplTreino(state);
    if (activeTab === 'imprensa') el.innerHTML = tplImprensa(state);
  }

  function refreshActiveTab(state) { renderTab(state); }

  // ---- Início ----
  function tplInicio(state) {
    const p = state.player;
    const role = Career.coachDecision();
    const roleLabels = { titular: '🟢 Titular', banco: '🟡 Banco', relacionado: '🟠 Relacionado', reserva: '🔴 Reserva', lesionado: '🚑 Lesionado' };
    const c = state.competitions;
    const activeComps = [c.estadual, c.liga, c.copa, c.continental].filter(x => x && !x.champion).map(x => x.name);
    const seasonOver = activeComps.length === 0;
    const nt = state.nationalTournament;
    return `
      <div class="grid-2col">
        <div class="card">
          <h3>Status do técnico</h3>
          <div class="role-pill role-${role}">${roleLabels[role]}</div>
          <div class="stat-row">
            ${statChip('Forma', Math.round(p.form))}${statChip('Moral', Math.round(p.morale))}
            ${statChip('Fadiga', Math.round(100 - p.fitness))}${statChip('Popularidade', Math.round(p.popularity))}
          </div>
          <p class="muted small">🏋️ ${p.trainingTokens || 0} sessão(ões) de treino disponíveis esta semana</p>
        </div>
        <div class="card">
          ${nt ? `
            <h3>🌍 ${nt.competition}</h3>
            <p class="muted small">O calendário do clube está pausado enquanto a seleção disputa o torneio.</p>
            <button class="btn-primary" id="btnPlayRound">▶ Jogar pela seleção</button>
          ` : `
            <h3>Próxima rodada</h3>
            <p class="muted small">${seasonOver ? '' : 'Ainda em disputa: ' + activeComps.join(', ')}</p>
            ${seasonOver
        ? `<p class="muted">Todas as competições da temporada terminaram.</p><button class="btn-primary" id="btnEndSeason">Encerrar temporada</button>`
        : `<button class="btn-primary" id="btnPlayRound">▶ Jogar rodada</button>`}
          `}
        </div>
      </div>
      <div class="card">
        <h3>Últimos jogos</h3>
        <div class="matchlog">
          ${state.matchLog.slice(0, 6).map(m => `<div class="matchlog-item"><span class="rating ${m.rating === null ? 'rating-ok' : 'rating-' + ratingClass(m.rating)}">${m.rating === null ? '—' : m.rating.toFixed(1)}</span><span>${m.text}</span></div>`).join('') || '<p class="muted">Ainda sem partidas nesta temporada.</p>'}
        </div>
      </div>`;
  }

  function ratingClass(r) { return r >= 8 ? 'great' : r >= 6.5 ? 'good' : r >= 5 ? 'ok' : 'bad'; }

  // ---- Atleta ----
  function tplAtleta(state) {
    const p = state.player;
    const attrs = PlayerModel.ALL_ATTRS;
    return `
      <div class="grid-2col">
        <div class="card">
          <h3>${p.name}</h3>
          <div class="stat-row">${statChip('OVR', p.overall)}${statChip('POT', p.potential)}${statChip('Idade', p.age)}${statChip('Nível', p.level)}</div>
          <div class="xp-track"><div class="xp-fill" style="width:${Math.round(p.xp / p.xpToNext * 100)}%"></div></div>
          <p class="muted small">${p.xp} / ${p.xpToNext} XP para o próximo nível</p>
          <p>Clube: ${state.club.name} · Salário semanal: ${Career.formatMoney(p.contract.wageWeekly)}</p>
          <p class="muted small">Contrato até ${p.contract.startYear + p.contract.years} (${Transfers.contractYearsLeft(p.contract, state.year)} ano(s) restante(s))</p>
          <p>Valor de mercado: ${Career.formatMoney(p.marketValue)}</p>
          ${p.sponsor ? `<p class="muted small sponsor-line">${sponsorLogoImg(p.sponsor.sponsor, 22)} Patrocínio ativo: ${p.sponsor.sponsor.name} até ${p.sponsor.startYear + p.sponsor.durationSeasons}</p>` : ''}
          ${p.injury ? `<p class="warn">🚑 ${p.injury.type} — ${p.injury.weeksLeft} semana(s) restantes</p>` : ''}
          <h4>Habilidades desbloqueadas</h4>
          <div class="skill-list">${p.skills.length ? p.skills.map(s => `<span class="pill">${s}</span>`).join('') : '<span class="muted small">Nenhuma ainda</span>'}</div>
          <h4>Troféus</h4>
          <div class="skill-list">${p.trophies.length ? p.trophies.map(s => `<span class="pill pill-gold">🏆 ${s}</span>`).join('') : '<span class="muted small">Nenhum ainda</span>'}</div>
        </div>
        <div class="card">
          <h3>Atributos</h3>
          ${attrs.map(a => attrBar(a[0].toUpperCase() + a.slice(1), p.attributes[a])).join('')}
        </div>
      </div>
      <div class="card">
        <h3>Estatísticas da temporada</h3>
        <div class="stat-row">
          ${statChip('Jogos', p.seasonStats.matches)}${statChip('Gols', p.seasonStats.goals)}
          ${statChip('Assist.', p.seasonStats.assists)}${statChip('Média', p.seasonStats.avgRating || 0)}
          ${statChip('Craque', p.seasonStats.motm)}
        </div>
      </div>`;
  }

  // ---- Elenco ----
  // ---- Clube ----
  function tplClube(state) {
    const p = state.player;
    return `
      <div class="card">
        <h3>${state.club.name}</h3>
        <p class="muted small">Técnico: ${state.club.coach} · Estádio: ${state.club.stadium}</p>
        <p class="muted small">Sua moral atual: ${Math.round(p.morale)}/100</p>
      </div>
      <div class="card">
        <h3>💰 Pedir aumento salarial</h3>
        <p class="muted small">O clube pode aceitar ou recusar, dependendo do seu momento. Uma recusa derruba sua moral.</p>
        <button class="btn-primary" id="btnRequestRaise">Pedir aumento</button>
        <div id="raiseResult"></div>
      </div>
      <div class="card">
        <h3>📄 Pedir renovação antecipada</h3>
        <p class="muted small">Renove seu contrato antes do prazo terminar, sem esperar o fim da temporada.</p>
        <button class="btn-primary" id="btnRequestRenewal">Pedir renovação</button>
        <div id="renewalResult"></div>
      </div>
      <div class="card">
        <h3>🚪 Pedir para sair</h3>
        <p class="muted small">Mesmo com contrato vigente, você pode pedir para deixar o clube. Se recusado, sua moral cai.</p>
        <button class="btn-secondary" id="btnRequestLeave">Pedir para sair</button>
        <div id="leaveResult"></div>
      </div>`;
  }

  // ---- Calendário ----
  function tplCalendario(state) {
    const upcoming = Career.getUpcomingFixtures();
    const upcomingHtml = upcoming.length ? upcoming.map(f => `
      <div class="fixture-row">
        <span class="fixture-comp">${f.competition}</span>
        ${f.bye ? '<span class="muted">Folga nesta rodada</span>' : `<span class="fixture-vs">${f.isHome ? 'vs' : '@'} ${crestImg(f.opponent, 20)} ${f.opponent.name}</span>`}
      </div>`).join('') : '<p class="muted small">Nenhum jogo agendado no momento — jogue a próxima rodada para ver o que vem a seguir.</p>';

    const recentHtml = state.matchLog.slice(0, 10).map(m => `
      <div class="fixture-row">
        <span class="${m.rating === null ? 'muted small' : 'rating ' + ratingClass(m.rating)}">${m.rating === null ? '—' : m.rating.toFixed(1)}</span>
        <span class="small">${m.text}</span>
      </div>`).join('') || '<p class="muted small">Nenhuma partida disputada ainda.</p>';

    return `
      <div class="card">
        <h3>Próximos jogos</h3>
        <p class="muted small">Liga, copa e competições internacionais se intercalam ao longo da temporada, como na vida real.</p>
        ${upcomingHtml}
      </div>
      <div class="card">
        <h3>Resultados recentes</h3>
        ${recentHtml}
      </div>`;
  }

  function tplElenco(state) {
    const rows = state.squad.slice().sort((a, b) => b.overall - a.overall).map(pl => `
      <tr class="${pl.isStarter ? 'starter' : ''}">
        <td>${pl.name}</td><td>${DB.POSITION_NAMES[pl.position]}</td><td>${pl.age}</td>
        <td><strong>${pl.overall}</strong></td><td>${Career.formatMoney(pl.marketValue)}</td>
      </tr>`).join('');
    return `<div class="card">
      <h3>Elenco do ${state.club.name}</h3>
      <div class="table-scroll"><table class="squad-table"><thead><tr><th>Nome</th><th>Pos.</th><th>Idade</th><th>OVR</th><th>Valor</th></tr></thead>
      <tbody>${rows}</tbody></table></div>
    </div>`;
  }

  // ---- Competições (tabela + chaveamento) ----
  function tplCompeticoes(state) {
    const blocks = [];
    if (state.competitions.estadual) blocks.push(competitionBlock(state, 'estadual', state.competitions.estadual));
    if (state.competitions.liga) blocks.push(competitionBlock(state, 'liga', state.competitions.liga));
    if (state.competitions.copa) blocks.push(competitionBlock(state, 'copa', state.competitions.copa));
    else blocks.push(`<div class="card"><h3>${state.competitions._argCupName || 'Copa'}</h3><p class="muted">O chaveamento será definido quando as duas zonas da fase de grupos terminarem.</p></div>`);
    if (state.competitions.continental) blocks.push(competitionBlock(state, 'continental', state.competitions.continental));
    return blocks.join('');
  }

  // ---- Prêmios (Bola de Ouro / Chuteira de Ouro / Luva de Ouro) ----
  function tplPremios(state) {
    const races = Career.getAwardRaces();
    const goldenBoot = races.chuteiraDeOuro.map((r, i) => `
      <tr class="${r.isCareer ? 'current' : ''}"><td>${i + 1}</td><td>${r.name}</td><td>${r.club ? r.club.name : '—'}</td><td><strong>${r.goals}</strong></td></tr>`).join('');
    const ballonDor = races.bolaDeOuro.map((r, i) => `
      <tr class="${r.isCareer ? 'current' : ''}"><td>${i + 1}</td><td>${r.name}</td><td>${r.club ? r.club.name : '—'}</td><td><strong>${Math.round(r.score)}</strong></td></tr>`).join('');
    const glove = races.luvaDeOuro ? races.luvaDeOuro.map((r, i) => `
      <tr class="${r.isCareer ? 'current' : ''}"><td>${i + 1}</td><td>${r.name}</td><td>${r.club ? r.club.name : '—'}</td><td><strong>${r.conceded}</strong></td></tr>`).join('') : null;
    const artilheiro = races.artilheiroLiga.map((r, i) => `
      <tr class="${r.isCareer ? 'current' : ''}"><td>${i + 1}</td><td>${r.name}</td><td>${r.club ? r.club.name : '—'}</td><td><strong>${r.goals}</strong></td></tr>`).join('');
    const assistLider = races.assistLiderLiga.map((r, i) => `
      <tr class="${r.isCareer ? 'current' : ''}"><td>${i + 1}</td><td>${r.name}</td><td>${r.club ? r.club.name : '—'}</td><td><strong>${r.assists}</strong></td></tr>`).join('');
    return `
      <div class="card"><h3>🥇 Bola de Ouro</h3><p class="muted small">Prêmio disputado apenas por quem joga na Europa, como na vida real.${!races.playerIsEuropean ? ' Você não concorre atuando fora da Europa.' : ''}</p>
        <div class="table-scroll"><table class="standings-table"><thead><tr><th>#</th><th>Jogador</th><th>Clube</th><th>Pontos</th></tr></thead><tbody>${ballonDor}</tbody></table></div>
      </div>
      <div class="card"><h3>👟 Chuteira de Ouro</h3><p class="muted small">Artilharia europeia estimada.${!races.playerIsEuropean ? ' Você não concorre atuando fora da Europa.' : ''}</p>
        <div class="table-scroll"><table class="standings-table"><thead><tr><th>#</th><th>Jogador</th><th>Clube</th><th>Gols</th></tr></thead><tbody>${goldenBoot}</tbody></table></div>
      </div>
      ${glove ? `<div class="card"><h3>🧤 Luva de Ouro</h3><p class="muted small">Menos gols sofridos entre os goleiros observados.</p>
        <div class="table-scroll"><table class="standings-table"><thead><tr><th>#</th><th>Goleiro</th><th>Clube</th><th>Gols sofridos</th></tr></thead><tbody>${glove}</tbody></table></div>
      </div>` : ''}
      <div class="card"><h3>⚽ Artilheiro — ${races.leagueName}</h3>
        <div class="table-scroll"><table class="standings-table"><thead><tr><th>#</th><th>Jogador</th><th>Clube</th><th>Gols</th></tr></thead><tbody>${artilheiro}</tbody></table></div>
      </div>
      <div class="card"><h3>🅰️ Líder de Assistências — ${races.leagueName}</h3>
        <div class="table-scroll"><table class="standings-table"><thead><tr><th>#</th><th>Jogador</th><th>Clube</th><th>Assist.</th></tr></thead><tbody>${assistLider}</tbody></table></div>
      </div>`;
  }

  function renderStandingsRows(standings, myClubId, leagueCode) {
    return standings.map((s, i) => {
      const tier = leagueCode ? Career.qualificationTierFor(s.clubId, leagueCode) : null;
      const tierClass = tier === 'top' ? 'qualify-top' : tier === 'second' ? 'qualify-second' : '';
      return `
      <tr class="${s.clubId === myClubId ? 'current' : ''} ${tierClass}">
        <td>${i + 1}</td><td class="team-cell">${crestImg(s.club, 20)} ${s.club ? s.club.name : '—'}</td>
        <td>${s.pts}</td><td>${s.pj}</td><td>${s.v}</td><td>${s.e}</td><td>${s.d}</td><td>${s.gp}</td><td>${s.gc}</td><td>${s.sg}</td>
      </tr>`;
    }).join('');
  }
  function wrapStandingsTable(rows) {
    return `<div class="table-scroll"><table class="standings-table">
      <thead><tr><th>#</th><th>Clube</th><th>P</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th><th>SG</th></tr></thead>
      <tbody>${rows}</tbody></table></div>`;
  }

  function renderBracket(bracketPhase, state) {
    if (!bracketPhase.rounds.length || !bracketPhase.rounds[0].length) return '';
    const totalRoundsNeeded = Math.log2(bracketPhase.rounds[0].length) + 1;
    function roundLabel(ri) {
      const fromEnd = totalRoundsNeeded - 1 - ri;
      if (fromEnd === 0) return 'Final';
      if (fromEnd === 1) return 'Semifinal';
      if (fromEnd === 2) return 'Quartas de Final';
      if (fromEnd === 3) return 'Oitavas de Final';
      return `Rodada ${ri + 1}`;
    }
    const roundsHtml = bracketPhase.rounds.map((round, ri) => {
      const label = roundLabel(ri);
      const matches = round.map(pair => {
        const home = pair.home ? DB.CLUBS.find(c => c.id === pair.home) : null;
        const away = pair.away ? DB.CLUBS.find(c => c.id === pair.away) : null;
        const involvesPlayer = pair.home === state.club.id || pair.away === state.club.id;
        return `<div class="bracket-match ${involvesPlayer ? 'current' : ''}">
          <span>${home ? home.name : 'BYE'}</span><span class="muted small">vs</span><span>${away ? away.name : 'BYE'}</span>
        </div>`;
      }).join('');
      return `<div class="bracket-round"><h4>${label}</h4>${matches}</div>`;
    }).join('');
    return `<div class="bracket-scroll">${roundsHtml}</div>`;
  }

  function competitionBlock(state, key, phase) {
    const activeBadge = phase.champion ? '<span class="pill pill-gold">FINALIZADA</span>' : '<span class="pill pill-live">EM ANDAMENTO</span>';

    if (phase.type === 'liga') {
      const standings = Career.getStandings(key);
      const legend = key === 'liga' && DB.continentalFor(state.league) ? `<p class="muted small"><span class="legend-dot legend-top"></span> Classificação direta &nbsp; <span class="legend-dot legend-second"></span> Fase preliminar/2ª competição</p>` : '';
      return `<div class="card"><h3>${phase.name} ${activeBadge}</h3>${legend}${wrapStandingsTable(renderStandingsRows(standings, state.club.id, key === 'liga' ? state.league : null))}</div>`;
    }

    if (phase.type === 'grupos') {
      let body;
      if (phase.isSwiss) {
        const standings = League.sortedStandings(phase.table, id => DB.CLUBS.find(c => c.id === id));
        body = `<p class="muted small">Fase de liga — cada clube enfrenta ${phase.rounds.length} adversários diferentes; os 8 primeiros avançam direto ao mata-mata.</p>` + wrapStandingsTable(renderStandingsRows(standings, state.club.id));
      } else {
        body = phase.groups.map(g => {
          const standings = League.sortedStandings(g.table, id => DB.CLUBS.find(c => c.id === id));
          return `<h4>${g.name}</h4>${wrapStandingsTable(renderStandingsRows(standings, state.club.id))}`;
        }).join('');
      }
      if (phase.knockout) body += `<h4>Mata-mata</h4>${renderBracket(phase.knockout, state)}`;
      return `<div class="card"><h3>${phase.name} ${activeBadge}</h3>${body}</div>`;
    }

    return `<div class="card"><h3>${phase.name} ${activeBadge}</h3>${renderBracket(phase, state)}</div>`;
  }

  // ---- Treino ----
  const ATTR_LABELS = {
    velocidade: 'Velocidade', finalizacao: 'Finalização', passe: 'Passe', drible: 'Drible', fisico: 'Físico',
    cabeceio: 'Cabeceio', marcacao: 'Marcação', interceptacao: 'Interceptação', reflexo: 'Reflexo',
    posicionamento: 'Posicionamento', defesa: 'Defesa', resistencia: 'Resistência', controle: 'Controle', visao: 'Visão',
  };

  function tplTreino(state) {
    const plans = [
      ['finalizacao', 'Finalização', '⚽'], ['passe', 'Passe & Visão', '🎯'], ['fisico', 'Físico', '💪'],
      ['defesa', 'Defesa', '🛡️'], ['tecnica', 'Técnica & Drible', '🌀'], ['goleiro', 'Goleiro', '🧤'],
    ];
    const tokens = state.player.trainingTokens || 0;
    return `<div class="card">
      <h3>Plano de treino</h3>
      <p class="muted small">${tokens} sessão(ões) disponíveis · Fadiga atual: ${Math.round(100 - state.player.fitness)}%</p>
      ${tokens <= 0 ? '<p class="warn small">Sem sessões esta semana — jogue a próxima rodada para liberar mais treinos, como no calendário real de um clube.</p>' : ''}
      <div class="training-grid">
        ${plans.map(([key, label, icon]) => {
      const attrs = (Career.TRAINING_PLANS[key] || []).map(a => ATTR_LABELS[a] || a).join(', ');
      return `<button class="train-card" data-plan="${key}" ${tokens <= 0 ? 'disabled' : ''}>
              <span class="train-icon">${icon}</span>${label}
              <span class="train-attrs muted small">Aumenta: ${attrs}</span>
            </button>`;
    }).join('')}
      </div>
      <div id="trainResult"></div>
    </div>`;
  }

  // ---- Decision popups (transfer offers, sponsorships, interviews, call-ups) ----
  function popupCardHTML(item) {
    if (item.type === 'transfer_offer') return transferCard(item);
    if (item.type === 'sponsor_offer') return sponsorCard(item);
    if (item.type === 'interview') return interviewCard(item);
    if (item.type === 'call_up') return callUpCard(item);
    return '';
  }

  function showDecisionPopup(item) {
    const ov = ensureOverlay();
    ov.innerHTML = `<div class="modal">${popupCardHTML(item)}</div>`;
    return ov;
  }

  function transferCard(item) {
    const { club, fee, contractOffer } = item.data;
    return `<div class="card inbox-card" data-id="${item.id}">
      <div class="inbox-head">${crestImg(club, 40)}<div><h3>Proposta do ${club.name}</h3><span class="muted small">Taxa de transferência: ${Career.formatMoney(fee)}</span></div></div>
      <div class="stat-row">
        ${statChip('Salário/sem', Career.formatMoney(contractOffer.wageWeekly))}${statChip('Anos', contractOffer.years)}
        ${statChip('Luvas', Career.formatMoney(contractOffer.signingBonus))}${statChip('Cláusula', Career.formatMoney(contractOffer.releaseClause))}
      </div>
      <div class="negotiate-row">
        <button class="btn-ghost" data-action="neg-wage-up">Pedir salário maior</button>
        <button class="btn-ghost" data-action="neg-years-down">Reduzir anos</button>
        <button class="btn-ghost" data-action="neg-clause-up">Elevar cláusula</button>
      </div>
      <div class="btn-row"><button class="btn-primary" data-action="accept">Aceitar</button><button class="btn-secondary" data-action="reject">Recusar</button></div>
    </div>`;
  }

  function sponsorLogoImg(sponsor, size = 40) {
    const c = DB.getSponsorLogo(sponsor);
    return `<img class="sponsor-logo-img" width="${size}" height="${size}" src="${c.remote}" onerror="this.onerror=null;this.src='${c.fallback}'" alt="${sponsor.name}">`;
  }

  function sponsorCard(item) {
    const { sponsor, payment, bonusPerGoal, durationSeasons, objective } = item.data;
    return `<div class="card inbox-card" data-id="${item.id}">
      <div class="inbox-head">${sponsorLogoImg(sponsor, 44)}
        <div><h3>Patrocínio ${sponsor.name}</h3><span class="muted small">${sponsor.type}</span></div></div>
      <div class="stat-row">${statChip('Pagamento', Career.formatMoney(payment))}${statChip('Bônus/gol', Career.formatMoney(bonusPerGoal))}${statChip('Duração', durationSeasons + ' temp.')}</div>
      <p class="muted small">Objetivo: ${objective}</p>
      <div class="btn-row"><button class="btn-primary" data-action="accept">Aceitar</button><button class="btn-secondary" data-action="reject">Recusar</button></div>
    </div>`;
  }

  function interviewCard(item) {
    const t = item.data.template || { prompt: 'Um jornalista pergunta sobre seu momento na equipe.', options: [
      { key: 'humilde', label: '"O mérito é do grupo."' }, { key: 'confiante', label: '"Sei do meu potencial."' },
      { key: 'motivacional', label: '"Vamos em busca de mais!"' }, { key: 'critico', label: '"Podíamos ter feito mais."' } ] };
    return `<div class="card inbox-card" data-id="${item.id}">
      <h3>🎙️ Entrevista pós-jogo</h3>
      <p class="muted small">${t.prompt}</p>
      <div class="btn-row wrap">
        ${t.options.map(o => `<button class="btn-ghost" data-answer="${o.key}">${o.label}</button>`).join('')}
      </div>
    </div>`;
  }

  function callUpCard(item) {
    return `<div class="card inbox-card" data-id="${item.id}">
      <h3>📣 Convocação da Seleção</h3>
      <p>Você foi convocado para <strong>${item.data.competition}</strong> representando ${item.data.nationality}.</p>
      <div class="btn-row"><button class="btn-primary" data-action="accept">Aceitar convocação</button><button class="btn-secondary" data-action="reject">Recusar</button></div>
    </div>`;
  }

  // ---- Imprensa ----
  function tplImprensa(state) {
    return `<div class="card"><h3>Últimas notícias</h3>
      <div class="news-list">${state.news.map(n => `<div class="news-item"><strong>${n.title}</strong><p class="muted small">${n.body}</p></div>`).join('') || '<p class="muted">Nenhuma notícia ainda.</p>'}</div></div>`;
  }

  // =========================================================================
  // MATCH CENTER — interactive step-by-step overlay
  // =========================================================================
  let overlayEl = null;

  function ensureOverlay() {
    if (!overlayEl) {
      overlayEl = document.createElement('div');
      overlayEl.className = 'modal-overlay';
      document.body.appendChild(overlayEl);
    }
    return overlayEl;
  }
  function closeOverlay() { if (overlayEl) { overlayEl.remove(); overlayEl = null; } }

  // -----------------------------------------------------------------------
  // LIVE MATCH SCREEN — persistent scoreboard + clock + auto-scrolling
  // commentary ticker, pausing only when the player needs to make a
  // decision. matchInfo needs: homeTeamObj, awayTeamObj, competition,
  // isHome (whether the player's side is "home" for score orientation).
  // -----------------------------------------------------------------------
  function renderLiveMatch(matchInfo) {
    const ov = ensureOverlay();
    ov.innerHTML = `<div class="modal live-match-modal">
      <div class="live-header">
        <div class="live-team">${crestImg(matchInfo.homeTeamObj, 48)}<span>${matchInfo.homeTeamObj.name}</span></div>
        <div class="live-center">
          <div class="live-competition">${matchInfo.competition}</div>
          <div class="live-score" id="liveScore">0 - 0</div>
          <div class="live-clock" id="liveClock">0'</div>
        </div>
        <div class="live-team">${crestImg(matchInfo.awayTeamObj, 48)}<span>${matchInfo.awayTeamObj.name}</span></div>
      </div>
      <div class="speed-row" id="speedRow">
        <button class="speed-btn" data-speed="900">🐢 Lento</button>
        <button class="speed-btn active" data-speed="480">▶ Normal</button>
        <button class="speed-btn" data-speed="180">⏩ Rápido</button>
      </div>
      <div class="live-ticker" id="liveTicker"></div>
      <div class="live-decision" id="liveDecision"></div>
      <button class="btn-ghost btn-sm live-skip" id="liveSkipBtn">⏭ Pular para o próximo lance</button>
    </div>`;
    return ov;
  }

  function pushLiveTicker(text, minute, highlight) {
    const el = document.getElementById('liveTicker');
    if (!el) return;
    const line = document.createElement('p');
    line.className = 'ticker-line' + (highlight ? ' ticker-highlight' : '');
    line.innerHTML = `<span class="ticker-min">${minute}'</span> ${text}`;
    el.appendChild(line);
    el.scrollTop = el.scrollHeight;
  }

  function updateLiveScore(score, isHome) {
    const el = document.getElementById('liveScore');
    if (!el) return;
    const homeGoals = isHome ? score.for : score.against;
    const awayGoals = isHome ? score.against : score.for;
    el.textContent = `${homeGoals} - ${awayGoals}`;
  }

  function updateLiveClock(minute) {
    const el = document.getElementById('liveClock');
    if (el) el.textContent = (minute >= 90 ? '90+' : minute) + "'";
  }

  function showLiveDecision(beat) {
    const el = document.getElementById('liveDecision');
    if (!el) return null;
    el.innerHTML = `<div class="decision-box pulse">
      <p class="decision-prompt">${beat.prompt}</p>
      <div class="decision-options">${beat.options.map(o => `<button class="btn-decision" data-opt="${o.key}">${o.label}</button>`).join('')}</div>
    </div>`;
    return el;
  }
  function clearLiveDecision() {
    const el = document.getElementById('liveDecision');
    if (el) el.innerHTML = '';
  }

  function showIncidentCard(incident, onContinue) {
    const ov = ensureOverlay();
    ov.innerHTML = `<div class="modal card incident-card">
      <h2>${incident.title}</h2>
      <p>${incident.text}</p>
      <button class="btn-primary" id="incidentContinueBtn">Ver o resto do jogo</button>
    </div>`;
    document.getElementById('incidentContinueBtn').addEventListener('click', onContinue);
  }

  function renderRoundSummary(summary, onClose) {
    const ov = ensureOverlay();
    const scoreBlock = summary.played ? `
      <div class="final-score">
        <span>${summary.homeTeam}</span>
        <span class="score-num">${summary.homeGoals} — ${summary.awayGoals}</span>
        <span>${summary.awayTeam}</span>
      </div>
      <div class="rating rating-${ratingClass(summary.rating)} rating-lg">${summary.rating.toFixed(1)}</div>
      <div class="stat-row" style="justify-content:center">
        ${statChip('Seus gols', summary.playerGoals)}${statChip('Suas assist.', summary.playerAssists)}
      </div>
      ${summary.championWon ? '<p class="success">🏆 CAMPEÃO!</p>' : ''}
      ${summary.eliminated && !summary.championWon ? '<p class="warn">Eliminado na competição.</p>' : ''}
      ${summary.advanced ? '<p class="success">Classificado para a próxima fase!</p>' : ''}
    ` : summary.clubPlayedWithoutYou ? `
      <p class="muted">Você não foi relacionado para este jogo.</p>
      <div class="final-score">
        <span>${summary.homeTeam}</span>
        <span class="score-num">${summary.homeGoals} — ${summary.awayGoals}</span>
        <span>${summary.awayTeam}</span>
      </div>
      ${summary.eliminated ? '<p class="warn">Seu time foi eliminado na competição.</p>' : ''}
      ${summary.advanced ? '<p class="success">Seu time se classificou para a próxima fase!</p>' : ''}
    ` : summary.eliminated ? `<p class="warn">Sua seleção não avançou na fase de grupos.</p>` : `<p class="muted">Sua equipe folgou nesta rodada.</p>`;

    const others = (summary.otherResults || []).slice(0, 6).map(r => {
      const home = r.home || (r.pair ? nameOf(r.pair.home) : '');
      const away = r.away || (r.pair ? nameOf(r.pair.away) : '');
      if (r.homeGoals === undefined) return '';
      return `<div class="other-result"><span>${home}</span><span>${r.homeGoals}-${r.awayGoals}</span><span>${away}</span></div>`;
    }).join('');

    ov.innerHTML = `<div class="modal card match-modal">
      <h2>${summary.competition}</h2>
      ${scoreBlock}
      ${summary.phaseOver ? '<p class="pill pill-gold">Fase encerrada!</p>' : ''}
      ${others ? `<h4>Outros resultados da rodada</h4><div class="other-results">${others}</div>` : ''}
      <button class="btn-primary" id="closeRoundBtn">Continuar</button>
    </div>`;
    ov.querySelector('#closeRoundBtn').addEventListener('click', () => { closeOverlay(); onClose && onClose(); });
  }

  function nameOf(clubId) { const c = DB.CLUBS.find(x => x.id === clubId); return c ? c.name : '—'; }

  return {
    renderCreatePlayer, renderClubProposals, renderClubList, renderContractDecision, renderHub, refreshActiveTab,
    renderLiveMatch, pushLiveTicker, updateLiveScore, updateLiveClock, showLiveDecision, clearLiveDecision,
    renderRoundSummary, showIncidentCard, showDecisionPopup, closeOverlay,
    getActiveTab: () => activeTab,
  };
})();
